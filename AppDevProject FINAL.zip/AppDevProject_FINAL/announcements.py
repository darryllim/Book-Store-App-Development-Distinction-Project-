import shelve
class Announcements:

    def __init__(self, announcement):
        self.__announcement_id = 0
        self.__text = announcement

    def set_announcement(self, announcement):
        self.__text = announcement

    def set_announcement_id(self):
        db = shelve.open("database/shelve/announcement/announcement.db","c")
        try:
            announcement_dict = db["announcements"]
        except:
            self.__announcement_id = 0
        else:
            if len(announcement_dict) == 0:
                self.__announcement_id = 0
            else:
                ann_list = []
                for key in announcement_dict:
                    ann_list.append(key)
                self.__announcement_id = ann_list[-1]+1
            db.close()
        return self.__announcement_id

    def get_announcement(self):
        return self.__text

    def get_announcement_id(self):
        return self.__announcement_id
