class Book:
    def __init__(self,id,title,img,description,language,status,isbn13,price,category):
        self.__bookID=id
        self.__bookTitle=title
        self.__bookIMG=img
        self.__bookDescription=description
        self.__bookLanguage = language
        self.__bookStatus=status
        self.__isbn13=isbn13 #unique identifier
        self.__price=price
        self.__categoryList=category # horror...


    def get_bookID(self):
        return self.__bookID

    def get_bookTitle(self):
        return self.__bookTitle

    def get_bookIMG(self):
        return self.__bookIMG

    def get_bookDescription(self):
        return self.__bookDescription

    def get_bookLanguage(self):
        return self.__bookLanguage

    def get_bookStatus(self):
        return self.__bookStatus

    def get_isbn13(self):
        return self.__isbn13

    def get_price(self):
        return self.__price

    def get_category(self):
        return self.__categoryList

    def set_bookID(self,bookID):
        self.__bookID=bookID

    def set_bookTitle(self,bookTitle):
        self.__bookTitle=bookTitle

    def set_bookIMG(self,bookIMG):
        self.__bookIMG=bookIMG

    def set_bookDescription(self,Description):
        self.__bookDescription=Description

    def set_bookLanguage(self,language):
        self.__bookLanguage = language

    def set_bookStatus(self,bookStatus):
        self.__bookStatus=bookStatus

    def set_isbn13(self,isbn13):
        self.__isbn13=isbn13

    def set_price(self,price):
        self.__price=price

    def set_category(self,category):
        self.__categoryList=category

