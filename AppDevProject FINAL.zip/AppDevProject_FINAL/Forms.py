from wtforms import Form,StringField,RadioField,TextAreaField,SelectField,TextAreaField,PasswordField,validators,FloatField
from wtforms.fields.html5 import EmailField
from wtforms.validators import ValidationError
import shelve



class CreateUserForm(Form):
    name=StringField("Username",[validators.Length(min=1,max=9),validators.DataRequired()])
    email = EmailField('Email address', [validators.DataRequired(), validators.Email()])
    password = PasswordField('New Password', [validators.DataRequired(),validators.EqualTo('confirm', message='Passwords must match')])
    confirm = PasswordField('Repeat Password')


class UpdateProfileForm(Form):
    name=StringField("Username",[validators.Length(min=1,max=9),validators.DataRequired()])
    email = EmailField('Email address', [validators.DataRequired(), validators.Email()])
    image = StringField("Image")
    blog = TextAreaField("Blog",[validators.Length(max=1000),validators.DataRequired()]
)
class UpdateProfileEmployeeForm(Form):
    name=StringField("Username",[validators.Length(min=1,max=9),validators.DataRequired()])
    email = EmailField('Email address', [validators.DataRequired(), validators.Email()])
    image = StringField("Image")

class LoginForm(Form):
    name=StringField("Username",[validators.Length(min=1,max=9),validators.DataRequired()])
    password = PasswordField('Password')


class CreateBook(Form):
    title=StringField("TITLE:",[validators.Length(min=1,max=100),validators.DataRequired()])
    image=StringField("IMAGE:",[validators.Length(min=1,max=500),validators.DataRequired()])
    description=StringField("DECRIPTION:",[validators.Length(min=1,max=500),validators.DataRequired()])
    language=RadioField("LANGUAGE",choices=[("English","English"),("Chinese","Chinese"),("Japanese","Japanese")],default="F")
    status=RadioField("STATUS:",choices=[("Available","Available"),("Not Available","Not Available")],default="T")
    isbn13=StringField("ISBN13",[validators.Length(min=13,max=13),validators.DataRequired()])
    category1=RadioField("CATEGORY",choices=[("Cartoon","Cartoon"),("Not Cartoon","Not Cartoon")],default="T")
    category2=RadioField("",choices=[("Horror","Horror"),("Not Horror","Not Horror")],default="T")
    category3=RadioField("",choices=[("Fiction","Fiction"),("Not Fiction","Not Fiction")],default="T")
    price = FloatField("PRICE (eg. 10.00) :",[validators.DataRequired()])

class CreateAnnouncementForm(Form):
    announcement = TextAreaField('', [validators.Optional(), validators.DataRequired()])

class CreateSellForm(Form):
    title=StringField("TITLE:",[validators.Length(min=1,max=100),validators.DataRequired()])
    image=StringField("IMAGE:",[validators.Length(min=1,max=500),validators.DataRequired()])
    description=StringField("DESCRIPTION:",[validators.Length(min=1,max=500),validators.DataRequired()])
    language=RadioField("LANGUAGE",choices=[("English","English"),("Chinese","Chinese"),("Japanese","Japanese")],default="F")
    isbn13=StringField("ISBN13:",[validators.Length(min=13,max=13),validators.DataRequired()])

class UpdateUserForm(Form):
    name=StringField("Username",[validators.Length(min=1,max=9),validators.DataRequired()])
    email = EmailField('Email address', [validators.DataRequired(), validators.Email()])


class ForgetPasswordForm(Form):
    email = EmailField('Email address', [validators.DataRequired(), validators.Email()])

class ChangePasswordForm(Form):

    password = PasswordField('New Password', [validators.DataRequired(),validators.EqualTo('confirm', message='Passwords must match')])
    confirm = PasswordField('Repeat Password')

# class Payment(Form):
#     def validate_luhn(self,value):
#             digits = list(map(int,str(value)))
#             oddSum = sum(digits[-1::-2])
#             evnSum = sum([sum(divmod(2 * d, 10)) for d in digits[-2::-2]])
#             ans= (oddSum + evnSum) % 10 == 0
#             if ans==False:
#                 raise ValidationError('Invalid Card Number')
#
#     fname=StringField('fname',[validators.DataRequired()])
#     lname=StringField('lname',[validators.DataRequired()])
#     address=StringField('address',[validators.DataRequired()])
#     city=StringField('city',[validators.DataRequired()])
#     pcode=StringField('pcode',[validators.DataRequired()])
#     country=StringField('country',[validators.DataRequired()])
#     phone=StringField('phone',[validators.DataRequired()])
#     noc=StringField('noc',[validators.DataRequired()])
#     cno=StringField('cno',[validators.DataRequired()], validators.EqualTo('ans', message='Pls enter valid credit card'))
#     expd =StringField('expd',[validators.DataRequired()])
#     cvv=StringField('cvv',[validators.DataRequired()])
#     validate_luhn(cno)
