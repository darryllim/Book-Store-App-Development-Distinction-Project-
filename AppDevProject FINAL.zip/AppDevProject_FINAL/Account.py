class ParentAccount:
    def __init__(self, uid, name, password, email, image):
        self.__uid = uid
        self.__name = name
        self.__password = password
        self.__email = email
        self.__image = image

    # link to cus book for cus, using uid

    def get_uid(self):
        return self.__uid

    def get_name(self):
        return self.__name

    def get_password(self):
        return self.__password

    def get_email(self):
        return self.__email

    def get_image(self):
        return self.__image

    def set_uid(self, uid):
        self.__uid = uid

    def set_name(self, name):
        self.__name = name

    def set_password(self, password):
        self.__password = password

    def set_email(self, email):
        self.__email = email

    def set_image(self,image):
        self.__image = image




class CustomerAccount(ParentAccount):

    def __init__(self, uid, name, password, email, image, borrow, buy, sell, borrowed, suggest):
        super().__init__(uid, name, password, email,image)
        self.__blog = ""
        self.__borrowCart = borrow
        self.__buyCart = buy
        self.__sell = sell
        self.__borrowed = borrowed
        self.__suggest = suggest
        # self.__borrowedCart # leave it, for shopping cart

    def get_blog(self):
        return self.__blog

    def get_sell(self):
        return self.__sell

    def get_borrowCart(self):
        return self.__borrowCart

    def get_borrowed(self):
        return self.__borrowed

    def get_buyCart(self):
        return self.__buyCart

    def get_suggest(self):
        return self.__suggest

    def set_blog(self, blog):
        self.__blog = blog

    def set_borrowCart(self, borrow):
        self.__borrowCart = borrow

    def set_buyCart(self, buy):
        self.__buyCart = buy

    def set_sell(self,sell):
        self.__sell = sell

    def set_borrowed(self,borrowed):
        self.__borrowed = borrowed

    def set_suggest(self,suggest):
        self.__suggest = suggest



class EmployeeAccount(ParentAccount):

    def __init__(self, uid, name, password, email, image):
        super().__init__(uid, name, password, email, image)
        self.__log_storage = False

    def get_log_storage(self):
        return self.__log_storage

    def set_log_storage(self, log):
        self.__log_storage = log
