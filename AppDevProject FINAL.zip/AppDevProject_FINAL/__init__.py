from flask import Flask, render_template, request, redirect, url_for, flash, session
# from Forms import CreateUserForm
import shelve, announcements, os, Book, random
from faq import Questions
import os.path
from Forms import CreateUserForm, LoginForm, CreateBook, CreateAnnouncementForm, CreateSellForm, UpdateUserForm, \
    UpdateProfileForm, UpdateProfileEmployeeForm, ChangePasswordForm, ForgetPasswordForm
from Account import CustomerAccount, EmployeeAccount
import pymsgbox
import smtplib

app = Flask(__name__)
app.secret_key = "any_random_string"


@app.route('/')
def home():
    try:
        shelve.open("database/shelve/announcement/announcement.db", "r")
    except:
        try:
            session["user_session"]
        except:
            return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
        else:
            db = shelve.open("database/shelve/userInfo/account.db", "c")
            db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
            books_dict = db2["BookInfo"]
            suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
            cart2 = []
            for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                cart2.append(i.get_bookID())
            for i in db["userAcc"][session["user_uid"]].get_buyCart():
                cart2.append(i.get_bookID())
            final_books = []
            if suggest_dict == "":
                item = 0
            else:
                list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                dict = ["EngInfo", "ChInfo", "JpInfo"]
                largest_lang = 0
                lang = ""
                largest_cat = 0
                cat = ""
                item = 1
                final_books = []
                for i in range(int(len(list) / 2)):
                    if suggest_dict[list[i]] > largest_lang:
                        largest_lang = suggest_dict[list[i]]
                        lang = list[i]
                    if suggest_dict[list[i + 3]] > largest_cat:
                        largest_cat = suggest_dict[list[i + 3]]
                        cat = list[i + 3]
                if largest_lang >= largest_cat:
                    index = list.index(lang)
                    larg_dict = db2[dict[index]]
                    book_list = []
                    for key in larg_dict:
                        book = larg_dict.get(key)
                        book_list.append(book)
                    pop_list = []
                    for book in book_list:
                        print(cat, book.get_category())
                        if cat in book.get_category():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        book_list.pop(book_list.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(book_list) - 1)
                                while book_list[randoms].get_bookID() in cart2:
                                    book_list.pop(book_list.index(book_list[randoms]))
                                    randoms = random.randint(0, len(book_list) - 1)
                                final_books.append(book_list[randoms])
                                book_list.pop(book_list.index(book_list[randoms]))
                            except:
                                pass
                else:
                    book_list = []
                    semi_books = []
                    for key in books_dict:
                        book = books_dict.get(key)
                        book_list.append(book)
                    for book in book_list:
                        if cat in book.get_category():
                            semi_books.append(book)
                    pop_list = []
                    for book in semi_books:
                        if lang == book.get_bookLanguage():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        semi_books.pop(semi_books.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(semi_books) - 1)
                                if semi_books[randoms].get_bookID() in cart2:
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                                else:
                                    final_books.append(semi_books[randoms])
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                            except:
                                pass
            db.close()
            db2.close()
            print(suggest_dict)
            return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                   final_books=final_books)
    else:
        db = shelve.open("database/shelve/announcement/announcement.db", "c")
        announcements_dict = db["announcements"]
        db.close()
        db = shelve.open("database/shelve/userInfo/account.db", "c")
        try:
            suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
            db.close()
        except:
            return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
        else:
            db = shelve.open("database/shelve/userInfo/account.db", "c")
            db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
            books_dict = db2["BookInfo"]
            final_books = []
            cart2 = []
            for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                cart2.append(i.get_bookID())
            for i in db["userAcc"][session["user_uid"]].get_buyCart():
                cart2.append(i.get_bookID())
            if suggest_dict == "":
                item = 0
            else:
                list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                dict = ["EngInfo", "ChInfo", "JpInfo"]
                largest_lang = 0
                lang = ""
                largest_cat = 0
                cat = ""
                item = 1
                final_books = []
                for i in range(int(len(list) / 2)):
                    if suggest_dict[list[i]] > largest_lang:
                        largest_lang = suggest_dict[list[i]]
                        lang = list[i]
                    if suggest_dict[list[i + 3]] > largest_cat:
                        largest_cat = suggest_dict[list[i + 3]]
                        cat = list[i + 3]
                if largest_lang >= largest_cat:
                    index = list.index(lang)
                    larg_dict = db2[dict[index]]
                    book_list = []
                    for key in larg_dict:
                        book = larg_dict.get(key)
                        book_list.append(book)
                    pop_list = []
                    for book in book_list:
                        print(cat, book.get_category())
                        if cat in book.get_category():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        book_list.pop(book_list.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(book_list) - 1)
                                while book_list[randoms].get_bookID() in cart2:
                                    book_list.pop(book_list.index(book_list[randoms]))
                                    randoms = random.randint(0, len(book_list) - 1)
                                final_books.append(book_list[randoms])
                                book_list.pop(book_list.index(book_list[randoms]))
                            except:
                                pass
                else:
                    book_list = []
                    semi_books = []
                    for key in books_dict:
                        book = books_dict.get(key)
                        book_list.append(book)
                    for book in book_list:
                        if cat in book.get_category():
                            semi_books.append(book)
                    pop_list = []
                    for book in semi_books:
                        if lang == book.get_bookLanguage():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        semi_books.pop(semi_books.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(semi_books) - 1)
                                if semi_books[randoms].get_bookID() in cart2:
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                                else:
                                    final_books.append(semi_books[randoms])
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                            except:
                                pass
            db.close()
            db2.close()
            if len(announcements_dict) < 1:
                print(suggest_dict)
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books)
            else:
                ann_list = []
                for key in announcements_dict:
                    ann = announcements_dict.get(key)
                    ann_list.append(ann)
                print(suggest_dict)
                return render_template("home.html", count=len(ann_list), ann_list=ann_list,
                                       text="THERE ARE NO ANNOUNCEMENTS", item=item, final_books=final_books)


@app.route('/englishBooks')
def english():
    try:
        db = shelve.open("database/shelve/bookInfo/Book.db", "r")
        book_dict = db["EngInfo"]
    except:
        return render_template("englishBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
    else:
        db.close()
        if len(book_dict) < 1:
            return render_template("englishBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
        else:
            best_list = []
            new_list = []
            for key in book_dict:
                book = book_dict.get(key)
                best_list.append(book)
                new_list.append(book)
            while len(new_list) > 6:
                new_list.pop(len(new_list) - 7)
            new_list.reverse()
            best_list = random.sample(best_list, len(best_list))
            while len(best_list) > 6:
                best_list.pop()
            print(len(best_list))
            return render_template("englishBooks.html", count=len(new_list), new_list=new_list, best_list=best_list,
                                   text="THERE ARE NO BOOKS AVAILABLE")


@app.route("/moreenglish")
def moreeng():
    try:
        db = shelve.open("database/shelve/bookInfo/Book.db", "r")
        book_dict = db["EngInfo"]
    except:
        return render_template("englishBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
    else:
        db.close()
        if len(book_dict) < 1:
            return render_template("englishBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
        else:
            book_list = []
            for key in book_dict:
                book = book_dict.get(key)
                book_list.append(book)
            x = int(len(book_list) / 6)
            y = len(book_list) - x * 6

    return render_template("moreenglish.html", count=len(book_list), book_list=book_list,
                           text="THERE ARE NO BOOKS AVAILABLE", x=x, y=y, c=0)


@app.route("/moresales")
def moresales():
    try:
        db = shelve.open("database/shelve/bookInfo/Book.db", "r")
        book_dict = db["bought"]
    except:
        return redirect(url_for("sales"))
    else:
        db.close()
        if len(book_dict) < 1:
            return redirect(url_for("sales"))
        else:
            book_list = []
            for key in book_dict:
                book = book_dict.get(key)
                book_list.append(book)
            x = int(len(book_list) / 6)
            y = len(book_list) - x * 6

    return render_template("moresales.html", count=len(book_list), book_list=book_list,
                           text="THERE ARE NO SALES", x=x, y=y, c=0)


@app.route('/chineseBooks')
def chinese():
    try:
        db = shelve.open("database/shelve/bookInfo/Book.db", "r")
        book_dict = db["ChInfo"]
    except:
        return render_template("chineseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
    else:
        db.close()
        if len(book_dict) < 1:
            return render_template("chineseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
        else:
            best_list = []
            new_list = []
            for key in book_dict:
                book = book_dict.get(key)
                best_list.append(book)
                new_list.append(book)
            while len(new_list) > 6:
                new_list.pop(len(new_list) - 7)
            new_list.reverse()
            best_list = random.sample(best_list, len(best_list))
            while len(best_list) > 6:
                best_list.pop()
            print(len(best_list))
            return render_template("chineseBooks.html", count=len(new_list), new_list=new_list, best_list=best_list,
                                   text="THERE ARE NO BOOKS AVAILABLE")


@app.route("/morechinese")
def morech():
    try:
        db = shelve.open("database/shelve/bookInfo/Book.db", "r")
        book_dict = db["ChInfo"]
    except:
        return render_template("chineseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
    else:
        db.close()
        if len(book_dict) < 1:
            return render_template("chineseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
        else:
            book_list = []
            for key in book_dict:
                book = book_dict.get(key)
                book_list.append(book)
            x = int(len(book_list) / 6)
            y = len(book_list) - x * 6

    return render_template("morechinese.html", count=len(book_list), book_list=book_list,
                           text="THERE ARE NO BOOKS AVAILABLE", x=x, y=y, c=0)


@app.route('/japaneseBooks')
def japanese():
    try:
        db = shelve.open("database/shelve/bookInfo/Book.db", "r")
        book_dict = db["JpInfo"]
    except:
        return render_template("japaneseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
    else:
        db.close()
        if len(book_dict) < 1:
            return render_template("japaneseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
        else:
            best_list = []
            new_list = []
            for key in book_dict:
                book = book_dict.get(key)
                best_list.append(book)
                new_list.append(book)
            while len(new_list) > 6:
                new_list.pop(len(new_list) - 7)
            new_list.reverse()
            best_list = random.sample(best_list, len(best_list))
            while len(best_list) > 6:
                best_list.pop()
            print(len(best_list))
            return render_template("japaneseBooks.html", count=len(new_list), new_list=new_list, best_list=best_list,
                                   text="THERE ARE NO BOOKS AVAILABLE")


@app.route("/morejapanese")
def morejp():
    try:
        db = shelve.open("database/shelve/bookInfo/Book.db", "r")
        book_dict = db["JpInfo"]
    except:
        return render_template("japaneseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
    else:
        db.close()
        if len(book_dict) < 1:
            return render_template("japaneseBooks.html", count=0, text="THERE ARE NO BOOKS AVAILABLE")
        else:
            book_list = []
            for key in book_dict:
                book = book_dict.get(key)
                book_list.append(book)
            x = int(len(book_list) / 6)
            y = len(book_list) - x * 6

    return render_template("morejapanese.html", count=len(book_list), book_list=book_list,
                           text="THERE ARE NO BOOKS AVAILABLE", x=x, y=y, c=0)


@app.route('/staffhome')
def staffhome():
    try:
        session["employee_session"]
        try:
            shelve.open("database/shelve/announcement/announcement.db", "r")
        except:
            return render_template("staffhome.html", count=0, text="THERE ARE NO ANNOUNCEMENTS")
        else:
            db = shelve.open("database/shelve/announcement/announcement.db", "c")
            announcements_dict = db["announcements"]
            db.close()
            if len(announcements_dict) < 1:
                return render_template("staffhome.html", count=0, text="THERE ARE NO ANNOUNCEMENTS")
            else:
                ann_list = []
                for key in announcements_dict:
                    ann = announcements_dict.get(key)
                    ann_list.append(ann)
                return render_template("staffhome.html", count=len(ann_list), ann_list=ann_list,
                                       text="THERE ARE NO ANNOUNCEMENTS")
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login")) #  url manipulation prevention
        else:
            return redirect(url_for("home"))


@app.route('/addannouncement', methods=['GET', 'POST'])
def addannouncement():
    try:
        session["employee_session"]
        announcement = CreateAnnouncementForm(request.form)
        if request.method == 'POST' and announcement.validate():
            announcement_dict = {}
            db = shelve.open('database/shelve/announcement/announcement.db', 'c')
            try:
                announcement_dict = db["announcements"]
            except:
                print("Error in retrieving announcements from announcement.db.")
            ann = announcements.Announcements(announcement.announcement.data)
            announcement_dict[ann.set_announcement_id()] = ann
            db["announcements"] = announcement_dict
            db.close()
            return redirect(url_for("staffhome"))
        return render_template("addannouncement.html", form=announcement)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/deleteann/<int:id>', methods=['POST'])
def delete_ann(id):
    try:
        session["employee_session"]
        db = shelve.open('database/shelve/announcement/announcement.db', 'w')
        ann_dict = db["announcements"]
        ann_dict.pop(id)
        db['announcements'] = ann_dict
        db.close()
        return redirect(url_for('staffhome'))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/faq", methods=["GET", "POST"])
def faq():
    ques = CreateAnnouncementForm(request.form)
    if request.method == 'POST' and ques.validate():
        question_dict = {}
        db = shelve.open('database/shelve/faq/faq.db', 'c')
        try:
            question_dict = db["Question"]
        except:
            print("Error in retrieving questions from faq.db.")
        qn = Questions(ques.announcement.data)
        question_dict[qn.set_question_id()] = qn
        db["Question"] = question_dict
        db.close()
        return redirect(url_for("home"))
    try:
        shelve.open("database/shelve/faq/faq.db", "r")
    except:
        return render_template("faq.html", text="THERE ARE NO QUESTIONS", count2=0, form=ques)
    else:
        db = shelve.open("database/shelve/faq/faq.db", "c")
        question_dict = db["Question"]
        try:
            qna_dict = db["QNA"]
        except:
            qna_dict = {}
            print("Error in retrieving QNA from faq.db.")
        try:
            ans_dict = db["Answer"]
        except:
            ans_dict = {}
            print("Error in retrieving ans from faq.db.")
        db.close()
        if len(question_dict) < 1 and len(qna_dict) < 1:
            return render_template("faq.html", text="THERE ARE NO QUESTIONS", count2=0, form=ques)
        else:
            qn_list = []
            qna_list = []
            for key in question_dict:
                qn = question_dict.get(key)
                qn_list.append(qn)
            for key in qna_dict:
                qn = qna_dict.get(key)
                qna_list.append(qn)

            return render_template("faq.html", qna_list=qna_list,
                                   ans_dict=ans_dict, count2=len(qna_list),
                                   text="THERE ARE NO QUESTIONS", form=ques)


@app.route("/cfaq")
def cfaq():
    try:
        session["employee_session"]
        try:
            shelve.open("database/shelve/faq/faq.db", "r")
        except:
            return render_template("cfaq.html", count=0, text="THERE ARE NO QUESTIONS", count2=0)
        else:
            db = shelve.open("database/shelve/faq/faq.db", "c")
            question_dict = db["Question"]
            try:
                qna_dict = db["QNA"]
            except:
                qna_dict = {}
                print("Error in retrieving QNA from faq.db.")
            try:
                ans_dict = db["Answer"]
            except:
                ans_dict = {}
                print("Error in retrieving ans from faq.db.")
            db.close()
            if len(question_dict) < 1 and len(qna_dict) < 1:
                return render_template("cfaq.html", count=0, text="THERE ARE NO QUESTIONS", count2=0)
            else:
                qn_list = []
                qna_list = []
                for key in question_dict:
                    qn = question_dict.get(key)
                    qn_list.append(qn)
                for key in qna_dict:
                    qn = qna_dict.get(key)
                    qna_list.append(qn)

                return render_template("cfaq.html", count=len(qn_list), qn_list=qn_list, qna_list=qna_list,
                                       ans_dict=ans_dict, count2=len(qna_list),
                                       text="THERE ARE NO QUESTIONS")

    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/ansqn/<int:id>', methods=['GET', 'POST'])
def ansqn(id):
    try:
        session["employee_session"]
        ans_form = CreateAnnouncementForm(request.form)
        if request.method == 'POST' and ans_form.validate():
            ans_dict = {}
            db = shelve.open('database/shelve/faq/faq.db', 'c')
            try:
                ans_dict = db["Answer"]
            except:
                print("Error in retrieving answers from faq.db.")
            ans = Questions(ans_form.announcement.data)
            ans_dict[id] = ans
            db["Answer"] = ans_dict
            qn_dict = db["Question"]
            try:
                qna_dict = db["QNA"]
            except:
                qna_dict = {}
                print("Error in retrieving QNA from faq.db.")
            qna_dict[id] = qn_dict[id]
            qn_dict.pop(id)
            db["QNA"] = qna_dict
            db["Question"] = qn_dict
            db.close()
            return redirect(url_for("cfaq"))
        else:
            db = shelve.open("database/shelve/faq/faq.db", "r")
            qn_dict = db["Question"]
            db.close()
            qn = qn_dict.get(id)
            return render_template("ansqn.html", qn=qn, form=ans_form)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/updateans/<int:id>", methods=["GET", "POST"])
def updateans(id):
    try:
        session["employee_session"]
        form = CreateAnnouncementForm(request.form)

        if request.method == "POST" and form.validate():

            ans_dict = {}
            db = shelve.open('database/shelve/faq/faq.db', 'c')
            ans_dict = db['Answer']

            ans = ans_dict.get(id)
            ans.set_question(form.announcement.data)

            db['Answer'] = ans_dict
            db.close()

            return redirect(url_for("cfaq"))

        else:

            db = shelve.open('database/shelve/faq/faq.db', 'c')
            ans_dict = db['Answer']
            qn_dict = db['QNA']
            db.close()
            qn = qn_dict.get(id)
            ans = ans_dict.get(id)
            form.announcement.data = ans.get_question()

            return render_template('updateans.html', form=form, qn=qn)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/deleteaqn/<int:id>', methods=['POST'])
def delete_aqn(id):
    try:
        session["employee_session"]
        db = shelve.open('database/shelve/faq/faq.db', 'w')
        qna_dict = db["QNA"]

        qna_dict.pop(id)
        db['QNA'] = qna_dict
        qna_dict = db["Answer"]

        qna_dict.pop(id)
        db['Answer'] = qna_dict
        db.close()
        return redirect(url_for('cfaq'))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/deleteqn/<int:id>', methods=['POST'])
def delete_qn(id):
    try:
        session["employee_session"]
        db = shelve.open('database/shelve/faq/faq.db', 'w')
        qn_dict = db["Question"]

        qn_dict.pop(id)
        db['Question'] = qn_dict
        db.close()
        return redirect(url_for('cfaq'))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/sellbook', methods=['GET', 'POST'])
def sellbook():
    sell_book_form = CreateSellForm(request.form)
    try:
        session['user_session'] = session['user_session']
    except:
        return redirect((url_for("login")))
    else:
        if request.method == 'POST' and sell_book_form.validate():
            sell_dict = {}
            db = shelve.open('database/shelve/sell/sell.db', 'c')
            db2 = shelve.open('database/shelve/userInfo/account.db', 'c')
            try:
                sell_dict = db['Sell']
            except:
                print("Error in retrieving data from sell.db")
            count = 1
            for id in sell_dict:
                if count <= sell_dict[id].get_bookID():
                    count = sell_dict[id].get_bookID() + 1
            book = Book.Book(count, sell_book_form.title.data, sell_book_form.image.data,
                             sell_book_form.description.data,
                             sell_book_form.language.data,
                             "Available", sell_book_form.isbn13.data, "", "")
            sell_dict[book.get_bookID()] = book
            db['Sell'] = sell_dict
            users_dict = db2["userAcc"]
            user = users_dict.get(session["user_uid"])
            print(user.get_sell())
            if user.get_sell() != "":
                books = user.get_sell()
            else:
                books = []
            books.append(book)
            user.set_sell(books)
            print(user.get_sell())
            users_dict[session["user_uid"]] = user
            db2["userAcc"] = users_dict
            print()
            db.close()
            db2.close()
            return redirect(url_for("home"))
        return render_template("sellbook.html", form=sell_book_form)


@app.route("/sales")
def sales():
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/bookInfo/Book.db", "c")
        try:
            data_dict_language = db["data_dict_language"]
        except:
            data_dict_language = {"English": 0, "Chinese": 0, "Japanese": 0}
            print("Error in retrving data from Book.db.")
        try:
            data_dict_language["English"]
        except:
            data_dict_language["English"] = 0
        try:
            data_dict_language["Chinese"]
        except:
            data_dict_language["Chinese"] = 0
        try:
            data_dict_language["Japanese"]
        except:
            data_dict_language["Japanese"] = 0
        try:
            data_dict_category = db["data_dict_category"]
        except:
            data_dict_category = {"Horror": 0, "Fiction": 0, "Cartoon": 0, "HNF": 0, "HNC": 0, "FNC": 0}
            print("Error in retrieving data from Book.db.")
        try:
            data_dict_category["Horror"]
        except:
            data_dict_category["Horror"] = 0
        try:
            data_dict_category["Fiction"]
        except:
            data_dict_category["Fiction"] = 0
        try:
            data_dict_category["Cartoon"]
        except:
            data_dict_category["Cartoon"] = 0
        try:
            data_dict_category["HNF"]
        except:
            data_dict_category["HNF"] = 0
        try:
            data_dict_category["HNC"]
        except:
            data_dict_category["HNC"] = 0
        try:
            data_dict_category["FNC"]
        except:
            data_dict_category["FNC"] = 0
        try:
            data_dict_category["ALL"]
        except:
            data_dict_category["ALL"] = 0
        db["data_dict_language"] = data_dict_language
        db["data_dict_language"] = data_dict_language
        most_popular_cat = []
        most_popular = 0
        most_popular_name = ""
        least_popular_cat = []
        least_popular = 9999999
        least_popular_name = ""
        cat_list_least = ["Horror", "Fiction", "Cartoon", "HNF", "HNC", "FNC", "ALL"]
        cat_list_most = ["Horror", "Fiction", "Cartoon", "HNF", "HNC", "FNC", "ALL"]
        replace = ["HNC", "HNF", "FNC", "ALL", "HORROR AND CARTOON", "HORROR AND FICTION", "FICTION AND CARTOON",
                   "HORROR, FICTION AND CARTOON"]
        most_popular_lang = []
        most_popular_l = 0
        most_popular_lang_name = ""
        least_popular_lang = []
        least_popular_l = 9999999
        least_popular_lang_name = ""
        lang_list_least = ["English", "Chinese", "Japanese"]
        lang_list_most = ["English", "Chinese", "Japanese"]
        while True:
            for cat in cat_list_most:
                if data_dict_category[cat] >= most_popular:
                    most_popular = data_dict_category[cat]
                    most_popular_name = cat
            if most_popular_name.upper() not in most_popular_cat:
                most_popular_cat.append(most_popular_name.upper())
                cat_list_most.pop(cat_list_most.index(most_popular_name))
            else:
                break
        while True:
            for cat in cat_list_least:
                print(cat)
                if data_dict_category[cat] <= least_popular:
                    least_popular = data_dict_category[cat]
                    least_popular_name = cat
            if least_popular_name.upper() not in least_popular_cat:
                least_popular_cat.append(least_popular_name.upper())
                cat_list_least.pop(cat_list_least.index(least_popular_name))
            else:
                break
        for i in range(int(len(replace) / 2)):
            if replace[i] in most_popular_cat:
                most_popular_cat[most_popular_cat.index(replace[i])] = replace[i + 4]
            if replace[i] in least_popular_cat:
                least_popular_cat[least_popular_cat.index(replace[i])] = replace[i + 4]
        while True:
            for lang in lang_list_most:
                if data_dict_language[lang] >= most_popular_l:
                    most_popular_l = data_dict_language[lang]
                    most_popular_lang_name = lang
            if most_popular_lang_name.upper() not in most_popular_lang:
                most_popular_lang.append(most_popular_lang_name.upper())
                lang_list_most.pop(lang_list_most.index(most_popular_lang_name))
            else:
                break
        while True:
            for lang in lang_list_least:
                if data_dict_language[lang] <= least_popular_l:
                    least_popular_l = data_dict_language[lang]
                    least_popular_lang_name = lang
            if least_popular_lang_name.upper() not in least_popular_lang:
                least_popular_lang.append(least_popular_lang_name.upper())
                lang_list_least.pop(lang_list_least.index(least_popular_lang_name))
            else:
                break
        try:
            books = db["bought"]
            book_list = []
            for key in books:
                book = books.get(key)
                book_list.append(book)
            book_list.reverse()
            book_list = book_list[0:6]
            items = 1
        except:
            book_list = "THERE ARE NO SALES"
            items = 0
        db.close()
        print(book_list)
        return render_template("sales.html", category=data_dict_category, language=data_dict_language,
                               most_popular_cat=most_popular_cat, least_popular_cat=least_popular_cat,
                               most_popular_lang=most_popular_lang, least_popular_lang=least_popular_lang,
                               book_list=book_list, items=items)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/deleteuser/<int:id>', methods=['POST'])
def delete_users(id):
    try:
        session["employee_session"]
        db = shelve.open('database/shelve/userInfo/account.db', 'w')
        user_dict = db["userAcc"]

        user_dict.pop(id)
        db['userAcc'] = user_dict
        db.close()
        return redirect(url_for('musers'))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/updateuser/<int:id>", methods=["GET", "POST"])
def updateuser(id):
    try:
        session["employee_session"]
        update_user_form = UpdateUserForm(request.form)

        if request.method == "POST" and update_user_form.validate():

            users_dict = {}
            db = shelve.open('database/shelve/userInfo/account.db', 'c')
            users_dict = db['userAcc']

            user = users_dict.get(id)
            user.set_name(update_user_form.name.data)
            user.set_email(update_user_form.email.data)

            db['userAcc'] = users_dict
            db.close()

            return redirect(url_for("musers"))

        else:

            db = shelve.open('database/shelve/userInfo/account.db', 'c')
            users_dict = db['userAcc']
            db.close()

            user = users_dict.get(id)
            update_user_form.name.data = user.get_name()
            update_user_form.email.data = user.get_email()

            return render_template('updateuser.html', form=update_user_form)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/mstaff")
def mstaff():
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/employeeInfo/account.db", "c")
        employee_dict = db["employeeAcc"]
        db.close()
        emp_list = []
        for key in employee_dict:
            emp = employee_dict.get(key)
            emp_list.append(emp)
        return render_template("mstaff.html", emp_list=emp_list)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/deletestaff/<int:id>', methods=['POST'])
def delete_staff(id):
    try:
        session["employee_session"]
        db = shelve.open('database/shelve/employeeInfo/account.db', 'w')
        emp_dict = db["employeeAcc"]

        emp_dict.pop(id)
        db['employeeAcc'] = emp_dict
        db.close()
        return redirect(url_for('mstaff'))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/updatestaff/<int:id>", methods=["GET", "POST"])
def updatestaff(id):
    try:
        session["employee_session"]
        update_staff_form = UpdateUserForm(request.form)

        if request.method == "POST" and update_staff_form.validate():

            emp_dict = {}
            db = shelve.open('database/shelve/employeeInfo/account.db', 'c')
            emp_dict = db['employeeAcc']

            user = emp_dict.get(id)
            user.set_name(update_staff_form.name.data)
            user.set_email(update_staff_form.email.data)

            db['employeeAcc'] = emp_dict
            db.close()

            return redirect(url_for("mstaff"))

        else:

            db = shelve.open('database/shelve/employeeInfo/account.db', 'c')
            emp_dict = db['employeeAcc']
            db.close()

            user = emp_dict.get(id)
            update_staff_form.name.data = user.get_name()
            update_staff_form.email.data = user.get_email()

            return render_template('updatestaff.html', form=update_staff_form)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/createstaff", methods=['GET', 'POST'])
def createstaff():
    try:
        session["employee_session"]
        create_user_form = CreateUserForm(request.form)
        if request.method == "POST" and create_user_form.validate() and val_name_staff(
                create_user_form.name.data) == True:
            staff_dict = {}
            db = shelve.open("database/shelve/employeeInfo/account.db", "c")
            try:
                staff_dict = db["employeeAcc"]
            except:
                print("Error in retrieving Users from storage.db.")
            count = 1
            for uid in staff_dict:
                if count <= staff_dict[uid].get_uid():
                    count = staff_dict[uid].get_uid() + 1
            user = EmployeeAccount(count, create_user_form.name.data, create_user_form.password.data,
                                   create_user_form.email.data, "https://freesvg.org/img/abstract-user-flat-4.png")
            staff_dict[count] = user
            db["employeeAcc"] = staff_dict
            users_dict = db["employeeAcc"]
            db.close()
            return redirect(url_for('mstaff'))
        else:
            return render_template("createstaff.html", form=create_user_form)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/displayBook/<int:id>")
def display_book(id):
    db = shelve.open("database/shelve/bookInfo/Book.db", "r")
    book_dict = db["BookInfo"]
    bookdispl = book_dict[id]
    db.close()
    print(id)
    b_list = []
    n_list = []
    id_list = []
    things = 1
    for key in book_dict:
        book = book_dict.get(key)
        id_list.append(key)
        b_list.append(book)

    if len(b_list) >= 7:
        done = []
        for i in range(6):
            count = random.randint(0, len(b_list) - 1)
            while id_list[count] == id or id_list[count] in done:
                count = random.randint(0, len(b_list) - 1)
            done.append(id_list[count])
            n_list.append(b_list[count])
    elif len(b_list) < 7 and len(b_list) > 1:
        done = []
        for i in range(len(b_list) - 1):
            print(id_list, b_list, n_list, done)
            count = random.randint(0, len(b_list) - 1)
            while id_list[count] == id or id_list[count] in done:
                count = random.randint(0, len(b_list) - 1)
            done.append(id_list[count])
            n_list.append(b_list[count])
    else:
        things = 0
    return render_template("displayBook.html", n_list=n_list, bookdispl=bookdispl,
                           text="THERE ARE NO OTHER BOOKS AVAILABLE", things=things)


@app.route("/borrow/<int:id>")
def borrow(id):
    try:
        session['user_session'] = session['user_session']
    except:
        return redirect((url_for("login"))) #url manipulation prevention
    else:
        db = shelve.open("database/shelve/userInfo/account.db", "c")
        db2 = shelve.open("database/shelve/bookInfo/Book.db", "r")
        books_dict = db2["BookInfo"]
        users_dict = db["userAcc"]
        user = users_dict.get(session["user_uid"])
        buy_lists = []
        borrow_lists = []
        for i in user.get_buyCart():
            buy_lists.append(i.get_bookID())
        for i in user.get_borrowCart():
            borrow_lists.append(i.get_bookID())
        if id in buy_lists or id in borrow_lists:
            db.close()
            db2.close()
            try:
                shelve.open("database/shelve/announcement/announcement.db", "r")
            except:
                try:
                    session["user_session"]
                except:
                    return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
                else:
                    db = shelve.open("database/shelve/userInfo/account.db", "c")
                    db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                    books_dict = db2["BookInfo"]
                    suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                    cart2 = []
                    for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                        cart2.append(i.get_bookID())
                    for i in db["userAcc"][session["user_uid"]].get_buyCart():
                        cart2.append(i.get_bookID())
                    final_books = []
                    if suggest_dict == "":
                        item = 0
                    else:
                        list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                        dict = ["EngInfo", "ChInfo", "JpInfo"]
                        largest_lang = 0
                        lang = ""
                        largest_cat = 0
                        cat = ""
                        item = 1
                        final_books = []
                        for i in range(int(len(list) / 2)):
                            if suggest_dict[list[i]] > largest_lang:
                                largest_lang = suggest_dict[list[i]]
                                lang = list[i]
                            if suggest_dict[list[i + 3]] > largest_cat:
                                largest_cat = suggest_dict[list[i + 3]]
                                cat = list[i + 3]
                        if largest_lang >= largest_cat:
                            index = list.index(lang)
                            larg_dict = db2[dict[index]]
                            book_list = []
                            for key in larg_dict:
                                book = larg_dict.get(key)
                                book_list.append(book)
                            pop_list = []
                            for book in book_list:
                                print(cat, book.get_category())
                                if cat in book.get_category():
                                    final_books.append(book)
                                    pop_list.append(book)
                            for i in pop_list:
                                book_list.pop(book_list.index(i))
                            pop_list2 = []
                            for i in final_books:
                                if i.get_bookID() in cart2:
                                    pop_list2.append(i)
                            for i in pop_list2:
                                final_books.pop(final_books.index(i))
                            if len(final_books) >= 6:
                                final_books = final_books[0:6]
                            else:
                                left = 6 - len(final_books)
                                for i in range(left):
                                    try:
                                        randoms = random.randint(0, len(book_list) - 1)
                                        while book_list[randoms].get_bookID() in cart2:
                                            book_list.pop(book_list.index(book_list[randoms]))
                                            randoms = random.randint(0, len(book_list) - 1)
                                        final_books.append(book_list[randoms])
                                        book_list.pop(book_list.index(book_list[randoms]))
                                    except:
                                        pass
                        else:
                            book_list = []
                            semi_books = []
                            for key in books_dict:
                                book = books_dict.get(key)
                                book_list.append(book)
                            for book in book_list:
                                if cat in book.get_category():
                                    semi_books.append(book)
                            pop_list = []
                            for book in semi_books:
                                if lang == book.get_bookLanguage():
                                    final_books.append(book)
                                    pop_list.append(book)
                            for i in pop_list:
                                semi_books.pop(semi_books.index(i))
                            pop_list2 = []
                            for i in final_books:
                                if i.get_bookID() in cart2:
                                    pop_list2.append(i)
                            for i in pop_list2:
                                final_books.pop(final_books.index(i))
                            if len(final_books) >= 6:
                                final_books = final_books[0:6]
                            else:
                                left = 6 - len(final_books)
                                for i in range(left):
                                    try:
                                        randoms = random.randint(0, len(semi_books) - 1)
                                        if semi_books[randoms].get_bookID() in cart2:
                                            semi_books.pop(semi_books.index(semi_books[randoms]))
                                        else:
                                            final_books.append(semi_books[randoms])
                                            semi_books.pop(semi_books.index(semi_books[randoms]))
                                    except:
                                        pass
                    db.close()
                    db2.close()
                    print(suggest_dict)
                    return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                           final_books=final_books, text1="THIS BOOK IS ALREADY IN YOUR CART",
                                           alert="danger")
            else:
                db = shelve.open("database/shelve/announcement/announcement.db", "c")
                announcements_dict = db["announcements"]
                db.close()
                db = shelve.open("database/shelve/userInfo/account.db", "c")
                db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                books_dict = db2["BookInfo"]
                suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                cart2 = []
                for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                    cart2.append(i.get_bookID())
                for i in db["userAcc"][session["user_uid"]].get_buyCart():
                    cart2.append(i.get_bookID())
                final_books = []
                if suggest_dict == "":
                    item = 0
                else:
                    list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                    dict = ["EngInfo", "ChInfo", "JpInfo"]
                    largest_lang = 0
                    lang = ""
                    largest_cat = 0
                    cat = ""
                    item = 1
                    final_books = []
                    for i in range(int(len(list) / 2)):
                        if suggest_dict[list[i]] > largest_lang:
                            largest_lang = suggest_dict[list[i]]
                            lang = list[i]
                        if suggest_dict[list[i + 3]] > largest_cat:
                            largest_cat = suggest_dict[list[i + 3]]
                            cat = list[i + 3]
                    if largest_lang >= largest_cat:
                        index = list.index(lang)
                        larg_dict = db2[dict[index]]
                        book_list = []
                        for key in larg_dict:
                            book = larg_dict.get(key)
                            book_list.append(book)
                        pop_list = []
                        for book in book_list:
                            print(cat, book.get_category())
                            if cat in book.get_category():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            book_list.pop(book_list.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                print(len(book_list))
                                try:
                                    randoms = random.randint(0, len(book_list) - 1)
                                    while book_list[randoms].get_bookID() in cart2:
                                        book_list.pop(book_list.index(book_list[randoms]))
                                        randoms = random.randint(0, len(book_list) - 1)
                                    final_books.append(book_list[randoms])
                                    book_list.pop(book_list.index(book_list[randoms]))
                                except:
                                    pass
                    else:
                        book_list = []
                        semi_books = []
                        for key in books_dict:
                            book = books_dict.get(key)
                            book_list.append(book)
                        for book in book_list:
                            if cat in book.get_category():
                                semi_books.append(book)
                        pop_list = []
                        for book in semi_books:
                            if lang == book.get_bookLanguage():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            semi_books.pop(semi_books.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(semi_books) - 1)
                                    if semi_books[randoms].get_bookID() in cart2:
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                    else:
                                        final_books.append(semi_books[randoms])
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                except:
                                    pass
                db.close()
                db2.close()
                if len(announcements_dict) < 1:
                    print(suggest_dict)
                    return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                           final_books=final_books, text1="THIS BOOK IS ALREADY IN YOUR CART",
                                           alert="danger")
                else:
                    ann_list = []
                    for key in announcements_dict:
                        ann = announcements_dict.get(key)
                        ann_list.append(ann)
                    print(suggest_dict)
                    return render_template("home.html", count=len(ann_list), ann_list=ann_list,
                                           text="THERE ARE NO ANNOUNCEMENTS", item=item, final_books=final_books,
                                           text1="THIS BOOK IS ALREADY IN YOUR CART", alert="danger")
        if user.get_borrowCart() != "":
            books = user.get_borrowCart()
        else:
            books = []
        if user.get_suggest() != "":
            suggest = user.get_suggest()
        else:
            suggest = {"English": 0, "Chinese": 0, "Japanese": 0, "Horror": 0, "Cartoon": 0, "Fiction": 0}
        suggest_list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
        for i in range(int(len(suggest_list) / 2)):
            if books_dict[id].get_bookLanguage() == suggest_list[i]:
                suggest[suggest_list[i]] += 1
            for x in books_dict[id].get_category():
                if x == suggest_list[i + 3]:
                    suggest[suggest_list[i + 3]] += 1
        books.append(books_dict[id])
        user.set_suggest(suggest)
        user.set_borrowCart(books)
        users_dict[session["user_uid"]] = user
        db["userAcc"] = users_dict
        db.close()
        db2.close()
        try:
            shelve.open("database/shelve/announcement/announcement.db", "r")
        except:
            try:
                session["user_session"]
            except:
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
            else:
                db = shelve.open("database/shelve/userInfo/account.db", "c")
                db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                books_dict = db2["BookInfo"]
                suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                cart2 = []
                for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                    cart2.append(i.get_bookID())
                for i in db["userAcc"][session["user_uid"]].get_buyCart():
                    cart2.append(i.get_bookID())
                final_books = []
                if suggest_dict == "":
                    item = 0
                else:
                    list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                    dict = ["EngInfo", "ChInfo", "JpInfo"]
                    largest_lang = 0
                    lang = ""
                    largest_cat = 0
                    cat = ""
                    item = 1
                    final_books = []
                    for i in range(int(len(list) / 2)):
                        if suggest_dict[list[i]] > largest_lang:
                            largest_lang = suggest_dict[list[i]]
                            lang = list[i]
                        if suggest_dict[list[i + 3]] > largest_cat:
                            largest_cat = suggest_dict[list[i + 3]]
                            cat = list[i + 3]
                    if largest_lang >= largest_cat:
                        index = list.index(lang)
                        larg_dict = db2[dict[index]]
                        book_list = []
                        for key in larg_dict:
                            book = larg_dict.get(key)
                            book_list.append(book)
                        pop_list = []
                        for book in book_list:
                            print(cat, book.get_category())
                            if cat in book.get_category():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            book_list.pop(book_list.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(book_list) - 1)
                                    while book_list[randoms].get_bookID() in cart2:
                                        book_list.pop(book_list.index(book_list[randoms]))
                                        randoms = random.randint(0, len(book_list) - 1)
                                    final_books.append(book_list[randoms])
                                    book_list.pop(book_list.index(book_list[randoms]))
                                except:
                                    pass
                    else:
                        book_list = []
                        semi_books = []
                        for key in books_dict:
                            book = books_dict.get(key)
                            book_list.append(book)
                        for book in book_list:
                            if cat in book.get_category():
                                semi_books.append(book)
                        pop_list = []
                        for book in semi_books:
                            if lang == book.get_bookLanguage():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            semi_books.pop(semi_books.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(semi_books) - 1)
                                    if semi_books[randoms].get_bookID() in cart2:
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                    else:
                                        final_books.append(semi_books[randoms])
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                except:
                                    pass
                db.close()
                db2.close()
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="THE BOOK HAS BEEN ADDED TO YOUR CART",
                                       alert="success")
        else:
            db = shelve.open("database/shelve/announcement/announcement.db", "c")
            announcements_dict = db["announcements"]
            db.close()
            db = shelve.open("database/shelve/userInfo/account.db", "c")
            db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
            books_dict = db2["BookInfo"]
            suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
            cart2 = []
            for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                cart2.append(i.get_bookID())
            for i in db["userAcc"][session["user_uid"]].get_buyCart():
                cart2.append(i.get_bookID())
            final_books = []
            if suggest_dict == "":
                item = 0
            else:
                list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                dict = ["EngInfo", "ChInfo", "JpInfo"]
                largest_lang = 0
                lang = ""
                largest_cat = 0
                cat = ""
                item = 1
                final_books = []
                for i in range(int(len(list) / 2)):
                    if suggest_dict[list[i]] > largest_lang:
                        largest_lang = suggest_dict[list[i]]
                        lang = list[i]
                    if suggest_dict[list[i + 3]] > largest_cat:
                        largest_cat = suggest_dict[list[i + 3]]
                        cat = list[i + 3]
                if largest_lang >= largest_cat:
                    index = list.index(lang)
                    larg_dict = db2[dict[index]]
                    book_list = []
                    for key in larg_dict:
                        book = larg_dict.get(key)
                        book_list.append(book)
                    pop_list = []
                    for book in book_list:
                        print(cat, book.get_category())
                        if cat in book.get_category():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        book_list.pop(book_list.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(book_list) - 1)
                                while book_list[randoms].get_bookID() in cart2:
                                    book_list.pop(book_list.index(book_list[randoms]))
                                    randoms = random.randint(0, len(book_list) - 1)
                                final_books.append(book_list[randoms])
                                book_list.pop(book_list.index(book_list[randoms]))
                            except:
                                pass
                else:
                    book_list = []
                    semi_books = []
                    for key in books_dict:
                        book = books_dict.get(key)
                        book_list.append(book)
                    for book in book_list:
                        if cat in book.get_category():
                            semi_books.append(book)
                    pop_list = []
                    for book in semi_books:
                        if lang == book.get_bookLanguage():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        semi_books.pop(semi_books.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(semi_books) - 1)
                                if semi_books[randoms].get_bookID() in cart2:
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                                else:
                                    final_books.append(semi_books[randoms])
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                            except:
                                pass
            db.close()
            db2.close()
            if len(announcements_dict) < 1:
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="THE BOOK HAS BEEN ADDED TO YOUR CART",
                                       alert="success")
            else:
                ann_list = []
                for key in announcements_dict:
                    ann = announcements_dict.get(key)
                    ann_list.append(ann)
                return render_template("home.html", count=len(ann_list), ann_list=ann_list,
                                       text="THERE ARE NO ANNOUNCEMENTS", item=item, final_books=final_books,
                                       text1="THE BOOK HAS BEEN ADDED TO YOUR CART", alert="success")


@app.route("/musers")
def musers():
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/userInfo/account.db", "c")
        try:
            user_dict = db["userAcc"]
        except:
            user_dict = {}
            print("No users created.")
        db.close()
        user_list = []
        borrowed = []
        buyCart = []
        sellCart = []
        for key in user_dict:
            user = user_dict.get(key)
            user_list.append(user)
        for user in user_list:
            if user.get_borrowed() == "" or len(user.get_borrowed()) == 0:
                borrowed.append(0)
            else:
                borrowed.append(len(user.get_borrowed()))
            if user.get_buyCart() == "" or len(user.get_buyCart()) == 0:
                buyCart.append(0)
            else:
                buyCart.append(len(user.get_buyCart()))
            if user.get_sell() == "" or len(user.get_sell()) == 0:
                sellCart.append(0)
            else:
                sellCart.append(len(user.get_sell()))
        return render_template("musers.html", user_list=user_list, buyCart=buyCart, borrowCart=borrowed,
                               sellCart=sellCart,
                               count=len(user_list))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/buy/<int:id>")
def buy(id):
    try:
        session['user_session'] = session['user_session']
    except:
        return redirect((url_for("login"))) #url manipulation prevention
    else:
        db = shelve.open("database/shelve/userInfo/account.db", "c")
        db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
        books_dict = db2["BookInfo"]
        users_dict = db["userAcc"]
        user = users_dict.get(session["user_uid"])
        buy_lists = []
        borrow_lists = []
        for i in user.get_buyCart():
            buy_lists.append(i.get_bookID())
        for i in user.get_borrowCart():
            borrow_lists.append(i.get_bookID())
        if id in buy_lists or id in borrow_lists:
            db.close()
            db2.close()
            try:
                shelve.open("database/shelve/announcement/announcement.db", "r")
            except:
                try:
                    session["user_session"]
                except:
                    return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
                else:
                    db = shelve.open("database/shelve/userInfo/account.db", "c")
                    db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                    books_dict = db2["BookInfo"]
                    suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                    cart2 = []
                    for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                        cart2.append(i.get_bookID())
                    for i in db["userAcc"][session["user_uid"]].get_buyCart():
                        cart2.append(i.get_bookID())
                    final_books = []
                    if suggest_dict == "":
                        item = 0
                    else:
                        list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                        dict = ["EngInfo", "ChInfo", "JpInfo"]
                        largest_lang = 0
                        lang = ""
                        largest_cat = 0
                        cat = ""
                        item = 1
                        final_books = []
                        for i in range(int(len(list) / 2)):
                            if suggest_dict[list[i]] > largest_lang:
                                largest_lang = suggest_dict[list[i]]
                                lang = list[i]
                            if suggest_dict[list[i + 3]] > largest_cat:
                                largest_cat = suggest_dict[list[i + 3]]
                                cat = list[i + 3]
                        if largest_lang >= largest_cat:
                            index = list.index(lang)
                            larg_dict = db2[dict[index]]
                            book_list = []
                            for key in larg_dict:
                                book = larg_dict.get(key)
                                book_list.append(book)
                            pop_list = []
                            for book in book_list:
                                print(cat, book.get_category())
                                if cat in book.get_category():
                                    final_books.append(book)
                                    pop_list.append(book)
                            for i in pop_list:
                                book_list.pop(book_list.index(i))
                            pop_list2 = []
                            for i in final_books:
                                if i.get_bookID() in cart2:
                                    pop_list2.append(i)
                            for i in pop_list2:
                                final_books.pop(final_books.index(i))
                            if len(final_books) >= 6:
                                final_books = final_books[0:6]
                            else:
                                left = 6 - len(final_books)
                                for i in range(left):
                                    try:
                                        randoms = random.randint(0, len(book_list) - 1)
                                        while book_list[randoms].get_bookID() in cart2:
                                            book_list.pop(book_list.index(book_list[randoms]))
                                            randoms = random.randint(0, len(book_list) - 1)
                                        final_books.append(book_list[randoms])
                                        book_list.pop(book_list.index(book_list[randoms]))
                                    except:
                                        pass
                        else:
                            book_list = []
                            semi_books = []
                            for key in books_dict:
                                book = books_dict.get(key)
                                book_list.append(book)
                            for book in book_list:
                                if cat in book.get_category():
                                    semi_books.append(book)
                            pop_list = []
                            for book in semi_books:
                                if lang == book.get_bookLanguage():
                                    final_books.append(book)
                                    pop_list.append(book)
                            for i in pop_list:
                                semi_books.pop(semi_books.index(i))
                            pop_list2 = []
                            for i in final_books:
                                if i.get_bookID() in cart2:
                                    pop_list2.append(i)
                            for i in pop_list2:
                                final_books.pop(final_books.index(i))
                            if len(final_books) >= 6:
                                final_books = final_books[0:6]
                            else:
                                left = 6 - len(final_books)
                                for i in range(left):
                                    try:
                                        randoms = random.randint(0, len(semi_books) - 1)
                                        print(semi_books[randoms].get_bookID(), cart2)
                                        if semi_books[randoms].get_bookID() in cart2:
                                            semi_books.pop(semi_books.index(semi_books[randoms]))
                                        else:
                                            final_books.append(semi_books[randoms])
                                            semi_books.pop(semi_books.index(semi_books[randoms]))
                                    except:
                                        pass
                    db.close()
                    db2.close()
                    print(suggest_dict)
                    return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                           final_books=final_books, text1="THIS BOOK IS ALREADY IN YOUR CART",
                                           alert="danger")
            else:
                db = shelve.open("database/shelve/announcement/announcement.db", "c")
                announcements_dict = db["announcements"]
                db.close()
                db = shelve.open("database/shelve/userInfo/account.db", "c")
                db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                books_dict = db2["BookInfo"]
                suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                cart2 = []
                for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                    cart2.append(i.get_bookID())
                for i in db["userAcc"][session["user_uid"]].get_buyCart():
                    cart2.append(i.get_bookID())
                final_books = []
                if suggest_dict == "":
                    item = 0
                else:
                    list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                    dict = ["EngInfo", "ChInfo", "JpInfo"]
                    largest_lang = 0
                    lang = ""
                    largest_cat = 0
                    cat = ""
                    item = 1
                    final_books = []
                    for i in range(int(len(list) / 2)):
                        if suggest_dict[list[i]] > largest_lang:
                            largest_lang = suggest_dict[list[i]]
                            lang = list[i]
                        if suggest_dict[list[i + 3]] > largest_cat:
                            largest_cat = suggest_dict[list[i + 3]]
                            cat = list[i + 3]
                    if largest_lang >= largest_cat:
                        index = list.index(lang)
                        larg_dict = db2[dict[index]]
                        book_list = []
                        for key in larg_dict:
                            book = larg_dict.get(key)
                            book_list.append(book)
                        pop_list = []
                        for book in book_list:
                            print(cat, book.get_category())
                            if cat in book.get_category():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            book_list.pop(book_list.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(book_list) - 1)
                                    while book_list[randoms].get_bookID() in cart2:
                                        book_list.pop(book_list.index(book_list[randoms]))
                                        randoms = random.randint(0, len(book_list) - 1)
                                    final_books.append(book_list[randoms])
                                    book_list.pop(book_list.index(book_list[randoms]))
                                except:
                                    pass
                    else:
                        book_list = []
                        semi_books = []
                        for key in books_dict:
                            book = books_dict.get(key)
                            book_list.append(book)
                        for book in book_list:
                            if cat in book.get_category():
                                semi_books.append(book)
                        pop_list = []
                        for book in semi_books:
                            if lang == book.get_bookLanguage():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            semi_books.pop(semi_books.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(semi_books) - 1)
                                    print(semi_books[randoms].get_bookID(), cart2)
                                    if semi_books[randoms].get_bookID() in cart2:
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                    else:
                                        final_books.append(semi_books[randoms])
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                except:
                                    pass
                db.close()
                db2.close()
                if len(announcements_dict) < 1:
                    print(suggest_dict)
                    return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                           final_books=final_books, text1="THIS BOOK IS ALREADY IN YOUR CART",
                                           alert="danger")
                else:
                    ann_list = []
                    for key in announcements_dict:
                        ann = announcements_dict.get(key)
                        ann_list.append(ann)
                    print(suggest_dict)
                    return render_template("home.html", count=len(ann_list), ann_list=ann_list,
                                           text="THERE ARE NO ANNOUNCEMENTS", item=item, final_books=final_books,
                                           text1="THIS BOOK IS ALREADY IN YOUR CART", alert="danger")
        if user.get_buyCart() != "":
            books = user.get_buyCart()
        else:
            books = []
        if user.get_suggest() != "":
            suggest = user.get_suggest()
        else:
            suggest = {"English": 0, "Chinese": 0, "Japanese": 0, "Horror": 0, "Cartoon": 0, "Fiction": 0}
        books.append(books_dict[id])
        suggest_list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
        for i in range(int(len(suggest_list) / 2)):
            if books_dict[id].get_bookLanguage() == suggest_list[i]:
                suggest[suggest_list[i]] += 1
            for x in books_dict[id].get_category():
                if x == suggest_list[i + 3]:
                    suggest[suggest_list[i + 3]] += 1
        user.set_buyCart(books)
        user.set_suggest(suggest)
        users_dict[session["user_uid"]] = user
        db["userAcc"] = users_dict
        db.close()
        db2.close()
        try:
            shelve.open("database/shelve/announcement/announcement.db", "r")
        except:
            try:
                session["user_session"]
            except:
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
            else:
                db = shelve.open("database/shelve/userInfo/account.db", "c")
                db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                books_dict = db2["BookInfo"]
                suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                cart2 = []
                for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                    cart2.append(i.get_bookID())
                for i in db["userAcc"][session["user_uid"]].get_buyCart():
                    cart2.append(i.get_bookID())
                final_books = []
                if suggest_dict == "":
                    item = 0
                else:
                    list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                    dict = ["EngInfo", "ChInfo", "JpInfo"]
                    largest_lang = 0
                    lang = ""
                    largest_cat = 0
                    cat = ""
                    item = 1
                    final_books = []
                    for i in range(int(len(list) / 2)):
                        if suggest_dict[list[i]] > largest_lang:
                            largest_lang = suggest_dict[list[i]]
                            lang = list[i]
                        if suggest_dict[list[i + 3]] > largest_cat:
                            largest_cat = suggest_dict[list[i + 3]]
                            cat = list[i + 3]
                    if largest_lang >= largest_cat:
                        index = list.index(lang)
                        larg_dict = db2[dict[index]]
                        book_list = []
                        for key in larg_dict:
                            book = larg_dict.get(key)
                            book_list.append(book)
                        pop_list = []
                        for book in book_list:
                            print(cat, book.get_category())
                            if cat in book.get_category():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            book_list.pop(book_list.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(book_list) - 1)
                                    while book_list[randoms].get_bookID() in cart2:
                                        book_list.pop(book_list.index(book_list[randoms]))
                                        randoms = random.randint(0, len(book_list) - 1)
                                    final_books.append(book_list[randoms])
                                    book_list.pop(book_list.index(book_list[randoms]))
                                except:
                                    pass
                    else:
                        book_list = []
                        semi_books = []
                        for key in books_dict:
                            book = books_dict.get(key)
                            book_list.append(book)
                        for book in book_list:
                            if cat in book.get_category():
                                semi_books.append(book)
                        pop_list = []
                        for book in semi_books:
                            if lang == book.get_bookLanguage():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            semi_books.pop(semi_books.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(semi_books) - 1)
                                    if semi_books[randoms].get_bookID() in cart2:
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                    else:
                                        final_books.append(semi_books[randoms])
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                except:
                                    pass
                db.close()
                db2.close()
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="THE BOOK HAS BEEN ADDED TO YOUR CART",
                                       alert="success")
        else:
            db = shelve.open("database/shelve/announcement/announcement.db", "c")
            announcements_dict = db["announcements"]
            db.close()
            db = shelve.open("database/shelve/userInfo/account.db", "c")
            db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
            books_dict = db2["BookInfo"]
            suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
            cart2 = []
            for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                cart2.append(i.get_bookID())
            for i in db["userAcc"][session["user_uid"]].get_buyCart():
                cart2.append(i.get_bookID())
            print(suggest_dict)
            final_books = []
            if suggest_dict == "":
                item = 0
            else:
                list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                dict = ["EngInfo", "ChInfo", "JpInfo"]
                largest_lang = 0
                lang = ""
                largest_cat = 0
                cat = ""
                item = 1
                final_books = []
                for i in range(int(len(list) / 2)):
                    if suggest_dict[list[i]] > largest_lang:
                        largest_lang = suggest_dict[list[i]]
                        lang = list[i]
                    if suggest_dict[list[i + 3]] > largest_cat:
                        largest_cat = suggest_dict[list[i + 3]]
                        cat = list[i + 3]
                if largest_lang >= largest_cat:
                    index = list.index(lang)
                    larg_dict = db2[dict[index]]
                    book_list = []
                    for key in larg_dict:
                        book = larg_dict.get(key)
                        book_list.append(book)
                        pop_list = []
                    for book in book_list:
                        print(cat, book.get_category())
                        if cat in book.get_category():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        book_list.pop(book_list.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(book_list) - 1)
                                while book_list[randoms].get_bookID() in cart2:
                                    book_list.pop(book_list.index(book_list[randoms]))
                                    randoms = random.randint(0, len(book_list) - 1)
                                final_books.append(book_list[randoms])
                                book_list.pop(book_list.index(book_list[randoms]))
                            except:
                                pass
                else:
                    book_list = []
                    semi_books = []
                    for key in books_dict:
                        book = books_dict.get(key)
                        book_list.append(book)
                    for book in book_list:
                        if cat in book.get_category():
                            semi_books.append(book)
                    pop_list = []
                    for book in semi_books:
                        if lang == book.get_bookLanguage():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        semi_books.pop(semi_books.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(semi_books) - 1)
                                if semi_books[randoms].get_bookID() in cart2:
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                                else:
                                    final_books.append(semi_books[randoms])
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                            except:
                                pass
            db.close()
            db2.close()
            if len(announcements_dict) < 1:
                print("yes")
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="THE BOOK HAS BEEN ADDED TO YOUR CART",
                                       alert="success")
            else:
                ann_list = []
                for key in announcements_dict:
                    ann = announcements_dict.get(key)
                    ann_list.append(ann)
                return render_template("home.html", count=len(ann_list), ann_list=ann_list,
                                       text="THERE ARE NO ANNOUNCEMENTS", item=item, final_books=final_books,
                                       text1="THE BOOK HAS BEEN ADDED TO YOUR CART", alert="success")


@app.route("/showsell/<int:id>")
def showsell(id):
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/userInfo/account.db", "r")
        users_dict = db["userAcc"]
        db.close()
        books = users_dict[id].get_sell()
        sell_list = []
        for sell in books:
            sell_list.append(sell)
        return render_template("showSell.html", sell_list=sell_list)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login")) #url manipulation prevention
        else:
            return redirect(url_for("home"))


@app.route("/showborrow/<int:id>")
def showborrow(id):
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/userInfo/account.db", "r")
        users_dict = db["userAcc"]
        db.close()
        books = users_dict[id].get_borrowed()
        borrow_list = []
        for borrow in books:
            borrow_list.append(borrow)
        return render_template("showBorrow.html", borrow_list=borrow_list)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))#url manipulation prevention
        else:
            return redirect(url_for("home"))


@app.route("/showbuy/<int:id>")
def showbuy(id):
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/userInfo/account.db", "r")
        users_dict = db["userAcc"]
        db.close()
        books = users_dict[id].get_buyCart()
        buy_list = []
        for buy in books:
            buy_list.append(buy)
        return render_template("showBuy.html", buy_list=buy_list)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login")) #url manipulation prevention
        else:
            return redirect(url_for("home"))


@app.route("/cart")
def cart():
    try:
        session['user_session'] = session['user_session']
    except:
        return redirect((url_for("login"))) #url manipulation prevention
    else:
        db = shelve.open("database/shelve/userInfo/account.db", "c")
        user_dict = db["userAcc"]
        user = user_dict[session["user_uid"]]
        if user.get_buyCart() == []:
            user.set_buyCart("")
        if user.get_borrowCart() == []:
            user.set_borrowCart("")
        borrow = 0
        buy = 0
        if user.get_borrowCart() != "" or len(user.get_borrowCart()) != 0:
            borrow = 1
        if user.get_buyCart() != "" or len(user.get_buyCart()) != 0:
            buy = 1
        total = 0
        for items in user.get_buyCart():
            price = items.get_price().split(".")
            total += int(price[0])
            length = len(price[1])
            ten = 1
            for i in range(length):
                ten = ten*10
            add = str(int(price[1])/ten)[:4]
            print(add)
            total += float(add)
        print(total)
        sub = "0.00"
        if int(total) != 0:
            split = str(total).split(".")[1]
            if len(split)==1:
                sub = str(total)+"0"
                total += 5
                total = str(total)+"0"
        return render_template("cart.html", user=user, text="THERE ARE NO ITEMS IN YOUR CART", borrow=borrow, buy=buy,
                               total=total, subtotal=sub)


@app.route("/deletebuy/<int:id>", methods=["POST"])
def delete_buy(id):
    db = shelve.open("database/shelve/userInfo/account.db")
    user_dict = db["userAcc"]
    cart_list = user_dict[session["user_uid"]].get_buyCart()
    for item in cart_list:
        if str(item.get_bookID()) == str(id):
            cart_list.pop(cart_list.index(item))
    user_dict[session["user_uid"]].set_buyCart(cart_list)
    db["userAcc"] = user_dict
    db.close()
    return redirect(url_for("cart"))


@app.route("/deleteborrow/<int:id>", methods=["POST"])
def delete_borrow(id):
    db = shelve.open("database/shelve/userInfo/account.db")
    user_dict = db["userAcc"]
    cart_list = user_dict[session["user_uid"]].get_borrowCart()
    for item in cart_list:
        if str(item.get_bookID()) == str(id):
            cart_list.pop(cart_list.index(item))
    user_dict[session["user_uid"]].set_borrowCart(cart_list)
    db["userAcc"] = user_dict
    db.close()
    return redirect(url_for("cart"))


@app.route('/deleteBook')
def deleteBook():
    try:
        session["user_session"]
        books_dict = {}
        db = shelve.open('database/shelve/bookInfo/Book.db', 'c')
        db2 = shelve.open("database/shelve/userInfo/account.db", "c")
        book_dict = db["BookInfo"]
        user_dict = db2["userAcc"]
        total = 0
        for items in user_dict[session["user_uid"]].get_buyCart():
            price = items.get_price().split(".")
            total += int(price[0])
            length = len(price[1])
            ten = 1
            for i in range(length):
                ten = ten*10
            add = str(int(price[1])/ten)[:4]
            print(add)
            total += float(add)
        print(total)
        split = str(total).split(".")[1]
        if len(split)==1:
            total += 5
            total = str(total)+"0"
        email = 'test123123ASIA@gmail.com'  # Your email
        password = 'efrfwesqa23@'  # Your email account password
        send_to_email = user_dict[session["user_uid"]].get_email()
        title = "SingBook Purchase Confirmation"
        content = "Books Bought:\n"
        for i in user_dict[session["user_uid"]].get_buyCart():
            content=content + "- "+i.get_bookTitle()+"\t\t\t$"+i.get_price()+"\n"
        content+= "- Shipping \t\t\t $5"
        content+="\nYour total is $"
        content+=str(total)
        print(content)
        message = 'Subject: {}\n\n{}'.format(title, content)
        subj = "SUBJECT"
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(email, password)
        server.sendmail(email, send_to_email, message)
        server.quit()
        key = ["BookInfo", "EngInfo", "ChInfo", "JpInfo"]
        try:
            buy_dict = db["bought"]
        except:
            buy_dict = {}
            print("Error in retrieving data from Book.db.")
        try:
            data_dict_language = db["data_dict_language"]
        except:
            data_dict_language = {"English": 0, "Chinese": 0, "Japanese": 0}
            print("Error in retrving data from Book.db.")
        try:
            data_dict_language["English"]
        except:
            data_dict_language["English"] = 0
        try:
            data_dict_language["Chinese"]
        except:
            data_dict_language["Chinese"] = 0
        try:
            data_dict_language["Japanese"]
        except:
            data_dict_language["Japanese"] = 0
        try:
            data_dict_category = db["data_dict_category"]
        except:
            data_dict_category = {"Horror": 0, "Fiction": 0, "Cartoon": 0, "HNF": 0, "HNC": 0, "FNC": 0}
            print("Error in retrieving data from Book.db.")
        try:
            data_dict_category["Horror"]
        except:
            data_dict_category["Horror"] = 0
        try:
            data_dict_category["Fiction"]
        except:
            data_dict_category["Fiction"] = 0
        try:
            data_dict_category["Cartoon"]
        except:
            data_dict_category["Cartoon"] = 0
        try:
            data_dict_category["HNF"]
        except:
            data_dict_category["HNF"] = 0
        try:
            data_dict_category["HNC"]
        except:
            data_dict_category["HNC"] = 0
        try:
            data_dict_category["FNC"]
        except:
            data_dict_category["FNC"] = 0
        try:
            data_dict_category["ALL"]
        except:
            data_dict_category["ALL"] = 0
        language_list = []
        id_list = []
        cat_list = []
        for index in user_dict[session["user_uid"]].get_buyCart():
            language_list.append(index.get_bookLanguage())
        for index in user_dict[session["user_uid"]].get_buyCart():
            cat_list.append(index.get_category())
        for index in user_dict[session["user_uid"]].get_buyCart():
            id_list.append(index.get_bookID())
        user_dict[session["user_uid"]].set_buyCart("")
        for lang in language_list:
            if lang.upper() == "ENGLISH":
                data_dict_language["English"] += 1
            elif lang.upper() == "CHINESE":
                data_dict_language["Chinese"] += 1
            elif lang.upper() == "JAPANESE":
                data_dict_language["Japanese"] += 1
        for category in cat_list:
            if len(category) > 1:
                if len(category) == 2:
                    if "Horror" and "Cartoon" in category:
                        data_dict_category["HNC"] += 1
                    elif "Horror" and "Fiction" in category:
                        data_dict_category["HNF"] += 1
                    elif "Fiction" and "Cartoon" in category:
                        data_dict_category["FNC"] += 1
                else:
                    data_dict_category["ALL"] += 1

            else:
                try:
                    if category[0].upper() == "HORROR":
                        data_dict_category["Horror"] += 1
                    elif category[0].upper() == "CARTOON":
                        data_dict_category["Cartoon"] += 1
                    elif category[0].upper() == "FICTION":
                        data_dict_category["Fiction"] += 1
                except:
                    pass
        db["data_dict_language"] = data_dict_language
        db["data_dict_category"] = data_dict_category
        for id in id_list:
            buy_dict[id] = book_dict[id]
            for i in range(len(key)):
                try:
                    books_dict = db[key[i]]
                except:
                    books_dict = {}
                try:
                    books_dict.pop(id)
                    db[key[i]] = books_dict
                except:
                    print("Book not found in Book[" + key[i] + "] database.")
        db["bought"] = buy_dict
        db.close()
        user_list = []
        for user in user_dict:
            item = user_dict.get(user)
            user_list.append(item)
        for id in id_list:
            for i in user_list:
                for x in i.get_borrowCart():
                    if str(x.get_bookID()) == str(id):
                        index = user_dict[i.get_uid()].get_borrowCart().index(x)
                        user_dict[i.get_uid()].get_borrowCart().pop(index)
            for i in user_list:
                for x in i.get_buyCart():
                    if str(x.get_bookID()) == str(id):
                        index = user_dict[i.get_uid()].get_buyCart().index(x)
                        user_dict[i.get_uid()].get_buyCart().pop(index)
        db2["userAcc"] = user_dict
        db2.close()
        try:
            shelve.open("database/shelve/announcement/announcement.db", "r")
        except:
            try:
                session["user_session"]
            except:
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
            else:
                db = shelve.open("database/shelve/userInfo/account.db", "c")
                db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                books_dict = db2["BookInfo"]
                suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                cart2 = []
                for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                    cart2.append(i.get_bookID())
                for i in db["userAcc"][session["user_uid"]].get_buyCart():
                    cart2.append(i.get_bookID())
                final_books = []
                if suggest_dict == "":
                    item = 0
                else:
                    list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                    dict = ["EngInfo", "ChInfo", "JpInfo"]
                    largest_lang = 0
                    lang = ""
                    largest_cat = 0
                    cat = ""
                    item = 1
                    final_books = []
                    for i in range(int(len(list) / 2)):
                        if suggest_dict[list[i]] > largest_lang:
                            largest_lang = suggest_dict[list[i]]
                            lang = list[i]
                        if suggest_dict[list[i + 3]] > largest_cat:
                            largest_cat = suggest_dict[list[i + 3]]
                            cat = list[i + 3]
                    if largest_lang >= largest_cat:
                        index = list.index(lang)
                        larg_dict = db2[dict[index]]
                        book_list = []
                        for key in larg_dict:
                            book = larg_dict.get(key)
                            book_list.append(book)
                        pop_list = []
                        for book in book_list:
                            print(cat, book.get_category())
                            if cat in book.get_category():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            book_list.pop(book_list.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(book_list) - 1)
                                    while book_list[randoms].get_bookID() in cart2:
                                        book_list.pop(book_list.index(book_list[randoms]))
                                        randoms = random.randint(0, len(book_list) - 1)
                                    final_books.append(book_list[randoms])
                                    book_list.pop(book_list.index(book_list[randoms]))
                                except:
                                    pass
                    else:
                        book_list = []
                        semi_books = []
                        for key in books_dict:
                            book = books_dict.get(key)
                            book_list.append(book)
                        for book in book_list:
                            if cat in book.get_category():
                                semi_books.append(book)
                        pop_list = []
                        for book in semi_books:
                            if lang == book.get_bookLanguage():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            semi_books.pop(semi_books.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(semi_books) - 1)
                                    if semi_books[randoms].get_bookID() in cart2:
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                    else:
                                        final_books.append(semi_books[randoms])
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                except:
                                    pass
                db.close()
                db2.close()
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="YOUR PURCHASE HAS BEEN COMPLETED",
                                       alert="success")
        else:
            db = shelve.open("database/shelve/announcement/announcement.db", "c")
            announcements_dict = db["announcements"]
            db.close()
            db = shelve.open("database/shelve/userInfo/account.db", "c")
            db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
            books_dict = db2["BookInfo"]
            suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
            cart2 = []
            for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                cart2.append(i.get_bookID())
            for i in db["userAcc"][session["user_uid"]].get_buyCart():
                cart2.append(i.get_bookID())
            final_books = []
            if suggest_dict == "":
                item = 0
            else:
                list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                dict = ["EngInfo", "ChInfo", "JpInfo"]
                largest_lang = 0
                lang = ""
                largest_cat = 0
                cat = ""
                item = 1
                final_books = []
                for i in range(int(len(list) / 2)):
                    if suggest_dict[list[i]] > largest_lang:
                        largest_lang = suggest_dict[list[i]]
                        lang = list[i]
                    if suggest_dict[list[i + 3]] > largest_cat:
                        largest_cat = suggest_dict[list[i + 3]]
                        cat = list[i + 3]
                if largest_lang >= largest_cat:
                    index = list.index(lang)
                    larg_dict = db2[dict[index]]
                    book_list = []
                    for key in larg_dict:
                        book = larg_dict.get(key)
                        book_list.append(book)
                    pop_list = []
                    for book in book_list:
                        print(cat, book.get_category())
                        if cat in book.get_category():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        book_list.pop(book_list.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(book_list) - 1)
                                while book_list[randoms].get_bookID() in cart2:
                                    book_list.pop(book_list.index(book_list[randoms]))
                                    randoms = random.randint(0, len(book_list) - 1)
                                final_books.append(book_list[randoms])
                                book_list.pop(book_list.index(book_list[randoms]))
                            except:
                                pass
                else:
                    book_list = []
                    semi_books = []
                    for key in books_dict:
                        book = books_dict.get(key)
                        book_list.append(book)
                    for book in book_list:
                        if cat in book.get_category():
                            semi_books.append(book)
                    pop_list = []
                    for book in semi_books:
                        if lang == book.get_bookLanguage():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        semi_books.pop(semi_books.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(semi_books) - 1)
                                if semi_books[randoms].get_bookID() in cart2:
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                                else:
                                    final_books.append(semi_books[randoms])
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                            except:
                                pass
            db.close()
            db2.close()
            if len(announcements_dict) < 1:
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="YOUR PURCHASE HAS BEEN COMPLETED",
                                       alert="success")
            else:
                ann_list = []
                for key in announcements_dict:
                    ann = announcements_dict.get(key)
                    ann_list.append(ann)
                return render_template("home.html", count=len(ann_list), ann_list=ann_list,
                                       text="THERE ARE NO ANNOUNCEMENTS", item=item, final_books=final_books,
                                       text1="YOUR PURCHASE HAS BEEN COMPLETED", alert="success")
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login")) #url manipulation prevention
        else:
            return redirect(url_for("home"))


@app.route("/borrowBook")
def borrow_book():
    try:
        session["user_session"]
        books_dict = {}
        db = shelve.open('database/shelve/bookInfo/Book.db', 'c')
        db2 = shelve.open("database/shelve/userInfo/account.db", "c")
        key = ["BookInfo", "EngInfo", "ChInfo", "JpInfo"]
        user_dict = db2["userAcc"]
        email = 'test123123ASIA@gmail.com'  # Your email
        password = 'efrfwesqa23@'  # Your email account password
        send_to_email = user_dict[session["user_uid"]].get_email()
        title = "SingBook Purchase Confirmation"
        content = "Books Borrowed:\n"
        for i in user_dict[session["user_uid"]].get_borrowCart():
            content=content + "- "+i.get_bookTitle()+"\n"
        content+= "- Shipping \t\t\t $5"
        content+="\nYour total is $5"
        print(content)
        message = 'Subject: {}\n\n{}'.format(title, content)
        subj = "SUBJECT"
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(email, password)
        server.sendmail(email, send_to_email, message)
        server.quit()
        try:
            data_dict_language = db["data_dict_language"]
        except:
            data_dict_language = {"English": 0, "Chinese": 0, "Japanese": 0}
            print("Error in retrving data from Book.db.")
        try:
            data_dict_language["English"]
        except:
            data_dict_language["English"] = 0
        try:
            data_dict_language["Chinese"]
        except:
            data_dict_language["Chinese"] = 0
        try:
            data_dict_language["Japanese"]
        except:
            data_dict_language["Japanese"] = 0
        try:
            data_dict_category = db["data_dict_category"]
        except:
            data_dict_category = {"Horror": 0, "Fiction": 0, "Cartoon": 0, "HNF": 0, "HNC": 0, "FNC": 0}
            print("Error in retrieving data from Book.db.")
        try:
            data_dict_category["Horror"]
        except:
            data_dict_category["Horror"] = 0
        try:
            data_dict_category["Fiction"]
        except:
            data_dict_category["Fiction"] = 0
        try:
            data_dict_category["Cartoon"]
        except:
            data_dict_category["Cartoon"] = 0
        try:
            data_dict_category["HNF"]
        except:
            data_dict_category["HNF"] = 0
        try:
            data_dict_category["HNC"]
        except:
            data_dict_category["HNC"] = 0
        try:
            data_dict_category["FNC"]
        except:
            data_dict_category["FNC"] = 0
        try:
            data_dict_category["ALL"]
        except:
            data_dict_category["ALL"] = 0
        language_list = []
        id_list = []
        cat_list = []
        for index in user_dict[session["user_uid"]].get_borrowCart():
            language_list.append(index.get_bookLanguage())
        for index in user_dict[session["user_uid"]].get_borrowCart():
            cat_list.append(index.get_category())
        borrowed_list = user_dict[session["user_uid"]].get_borrowed()
        if borrowed_list == "":
            borrowed_list = []
        elif borrowed_list == []:
            borrowed_list = []
        else:
            borrowed_list = user_dict[session["user_uid"]].get_borrowed()
        for i in user_dict[session["user_uid"]].get_borrowCart():
            borrowed_list.append(i)
        user_dict[session["user_uid"]].set_borrowed(borrowed_list)
        for index in user_dict[session["user_uid"]].get_borrowCart():
            id_list.append(index.get_bookID())
        user_dict[session["user_uid"]].set_borrowCart("")
        for lang in language_list:
            if lang.upper() == "ENGLISH":
                data_dict_language["English"] += 1
            elif lang.upper() == "CHINESE":
                data_dict_language["Chinese"] += 1
            elif lang.upper() == "JAPANESE":
                data_dict_language["Japanese"] += 1
        for category in cat_list:
            print(category)
            if len(category) > 1:
                if len(category) == 2:
                    if "Horror" and "Cartoon" in category:
                        data_dict_category["HNC"] += 1
                    elif "Horror" and "Fiction" in category:
                        data_dict_category["HNF"] += 1
                    elif "Fiction" and "Cartoon" in category:
                        data_dict_category["FNC"] += 1
                else:
                    data_dict_category["ALL"] += 1

            else:
                try:
                    if category[0].upper() == "HORROR":
                        data_dict_category["Horror"] += 1
                    elif category[0].upper() == "CARTOON":
                        data_dict_category["Cartoon"] += 1
                    elif category[0].upper() == "FICTION":
                        data_dict_category["Fiction"] += 1
                except:
                    pass
        db["data_dict_language"] = data_dict_language
        db["data_dict_category"] = data_dict_category
        for id in id_list:
            for i in range(len(key)):
                try:
                    books_dict = db[key[i]]
                except:
                    books_dict = {}
                try:
                    books_dict.pop(id)
                    db[key[i]] = books_dict
                except:
                    print("Book not found in Book[" + key[i] + "] database.")
        db.close()
        user_list = []
        for user in user_dict:
            item = user_dict.get(user)
            user_list.append(item)
        for id in id_list:
            for i in user_list:
                for x in i.get_borrowCart():
                    if str(x.get_bookID()) == str(id):
                        index = user_dict[i.get_uid()].get_borrowCart().index(x)
                        user_dict[i.get_uid()].get_borrowCart().pop(index)
            for i in user_list:
                for x in i.get_buyCart():
                    if str(x.get_bookID()) == str(id):
                        index = user_dict[i.get_uid()].get_buyCart().index(x)
                        user_dict[i.get_uid()].get_buyCart().pop(index)
        db2["userAcc"] = user_dict
        db2.close()
        try:
            shelve.open("database/shelve/announcement/announcement.db", "r")
        except:
            try:
                session["user_session"]
            except:
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=0)
            else:
                db = shelve.open("database/shelve/userInfo/account.db", "c")
                db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
                books_dict = db2["BookInfo"]
                suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
                cart2 = []
                for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                    cart2.append(i.get_bookID())
                for i in db["userAcc"][session["user_uid"]].get_buyCart():
                    cart2.append(i.get_bookID())
                final_books = []
                if suggest_dict == "":
                    item = 0
                else:
                    list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                    dict = ["EngInfo", "ChInfo", "JpInfo"]
                    largest_lang = 0
                    lang = ""
                    largest_cat = 0
                    cat = ""
                    item = 1
                    final_books = []
                    for i in range(int(len(list) / 2)):
                        if suggest_dict[list[i]] > largest_lang:
                            largest_lang = suggest_dict[list[i]]
                            lang = list[i]
                        if suggest_dict[list[i + 3]] > largest_cat:
                            largest_cat = suggest_dict[list[i + 3]]
                            cat = list[i + 3]
                    if largest_lang >= largest_cat:
                        index = list.index(lang)
                        larg_dict = db2[dict[index]]
                        book_list = []
                        for key in larg_dict:
                            book = larg_dict.get(key)
                            book_list.append(book)
                        pop_list = []
                        for book in book_list:
                            print(cat, book.get_category())
                            if cat in book.get_category():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            book_list.pop(book_list.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(book_list) - 1)
                                    while book_list[randoms].get_bookID() in cart2:
                                        book_list.pop(book_list.index(book_list[randoms]))
                                        randoms = random.randint(0, len(book_list) - 1)
                                    final_books.append(book_list[randoms])
                                    book_list.pop(book_list.index(book_list[randoms]))
                                except:
                                    pass
                    else:
                        book_list = []
                        semi_books = []
                        for key in books_dict:
                            book = books_dict.get(key)
                            book_list.append(book)
                        for book in book_list:
                            if cat in book.get_category():
                                semi_books.append(book)
                        pop_list = []
                        for book in semi_books:
                            if lang == book.get_bookLanguage():
                                final_books.append(book)
                                pop_list.append(book)
                        for i in pop_list:
                            semi_books.pop(semi_books.index(i))
                        pop_list2 = []
                        for i in final_books:
                            if i.get_bookID() in cart2:
                                pop_list2.append(i)
                        for i in pop_list2:
                            final_books.pop(final_books.index(i))
                        if len(final_books) >= 6:
                            final_books = final_books[0:6]
                        else:
                            left = 6 - len(final_books)
                            for i in range(left):
                                try:
                                    randoms = random.randint(0, len(semi_books) - 1)
                                    if semi_books[randoms].get_bookID() in cart2:
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                    else:
                                        final_books.append(semi_books[randoms])
                                        semi_books.pop(semi_books.index(semi_books[randoms]))
                                except:
                                    pass
                db.close()
                db2.close()
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="YOUR PURCHASE HAS BEEN COMPLETED",
                                       alert="success")
        else:
            db = shelve.open("database/shelve/announcement/announcement.db", "c")
            announcements_dict = db["announcements"]
            db.close()
            db = shelve.open("database/shelve/userInfo/account.db", "c")
            db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
            books_dict = db2["BookInfo"]
            suggest_dict = db["userAcc"][session["user_uid"]].get_suggest()
            cart2 = []
            for i in db["userAcc"][session["user_uid"]].get_borrowCart():
                cart2.append(i.get_bookID())
            for i in db["userAcc"][session["user_uid"]].get_buyCart():
                cart2.append(i.get_bookID())
            final_books = []
            if suggest_dict == "":
                item = 0
            else:
                list = ["English", "Chinese", "Japanese", "Horror", "Cartoon", "Fiction"]
                dict = ["EngInfo", "ChInfo", "JpInfo"]
                largest_lang = 0
                lang = ""
                largest_cat = 0
                cat = ""
                item = 1
                final_books = []
                for i in range(int(len(list) / 2)):
                    if suggest_dict[list[i]] > largest_lang:
                        largest_lang = suggest_dict[list[i]]
                        lang = list[i]
                    if suggest_dict[list[i + 3]] > largest_cat:
                        largest_cat = suggest_dict[list[i + 3]]
                        cat = list[i + 3]
                if largest_lang >= largest_cat:
                    index = list.index(lang)
                    larg_dict = db2[dict[index]]
                    book_list = []
                    for key in larg_dict:
                        book = larg_dict.get(key)
                        book_list.append(book)
                    pop_list = []
                    for book in book_list:
                        print(cat, book.get_category())
                        if cat in book.get_category():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        book_list.pop(book_list.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(book_list) - 1)
                                while book_list[randoms].get_bookID() in cart2:
                                    book_list.pop(book_list.index(book_list[randoms]))
                                    randoms = random.randint(0, len(book_list) - 1)
                                final_books.append(book_list[randoms])
                                book_list.pop(book_list.index(book_list[randoms]))
                            except:
                                pass
                else:
                    book_list = []
                    semi_books = []
                    for key in books_dict:
                        book = books_dict.get(key)
                        book_list.append(book)
                    for book in book_list:
                        if cat in book.get_category():
                            semi_books.append(book)
                    pop_list = []
                    for book in semi_books:
                        if lang == book.get_bookLanguage():
                            final_books.append(book)
                            pop_list.append(book)
                    for i in pop_list:
                        semi_books.pop(semi_books.index(i))
                    pop_list2 = []
                    for i in final_books:
                        if i.get_bookID() in cart2:
                            pop_list2.append(i)
                    for i in pop_list2:
                        final_books.pop(final_books.index(i))
                    if len(final_books) >= 6:
                        final_books = final_books[0:6]
                    else:
                        left = 6 - len(final_books)
                        for i in range(left):
                            try:
                                randoms = random.randint(0, len(semi_books) - 1)
                                if semi_books[randoms].get_bookID() in cart2:
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                                else:
                                    final_books.append(semi_books[randoms])
                                    semi_books.pop(semi_books.index(semi_books[randoms]))
                            except:
                                pass
            db.close()
            db2.close()
            if len(announcements_dict) < 1:
                return render_template("home.html", count=0, text="THERE ARE NO ANNOUNCEMENTS", item=item,
                                       final_books=final_books, text1="YOUR PURCHASE HAS BEEN COMPLETED",
                                       alert="success")
            else:
                ann_list = []
                for key in announcements_dict:
                    ann = announcements_dict.get(key)
                    ann_list.append(ann)
                return render_template("home.html", count=len(ann_list), ann_list=ann_list,
                                       text="THERE ARE NO ANNOUNCEMENTS", item=item, final_books=final_books,
                                       text1="YOUR PURCHASE HAS BEEN COMPLETED", alert="success")
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/returned/<int:id>")
def returned(id):
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/userInfo/account.db", "c")
        db2 = shelve.open("database/shelve/bookInfo/Book.db", "c")
        users_dict = db["userAcc"]
        book_dict = db2["BookInfo"]
        eng_dict = db2["EngInfo"]
        ch_dict = db2["ChInfo"]
        jp_dict = db2["JpInfo"]
        users_list = []
        id_list = []
        for i in users_dict:
            users_list.append(users_dict[i])
        for i in users_list:
            id_list.append(i.get_borrowed())
        for i in id_list:
            check_id = []
            for u in i:
                check_id.append(u.get_bookID())
            if id in check_id:
                book_list = i
                user = users_list[id_list.index(i)]
                for x in book_list:
                    if id == x.get_bookID():
                        book = x
                        if book.get_bookLanguage().upper() == "ENGLISH":
                            eng_dict[id] = book
                            db2["EngInfo"] = eng_dict
                        elif book.get_bookLanguage().upper() == "CHINESE":
                            ch_dict[id] = book
                            db2["ChInfo"] = ch_dict
                        elif book.get_bookLanguage().upper() == "JAPANESE":
                            jp_dict[id] = book
                            db2["JpInfo"] = jp_dict
                        book_dict[id] = book
                        db2["BookInfo"] = book_dict
                        book_list.pop(book_list.index(x))
                uid = user.get_uid()
                users_dict[uid].set_borrowed(book_list)
                db["userAcc"] = users_dict
                db.close()
                db2.close()

        return redirect(url_for("musers"))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/clearcachecat")
def clearcat():
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/bookInfo/Book.db", "c")
        db["data_dict_category"] = {"Horror": 0, "Fiction": 0, "Cartoon": 0, "HNF": 0, "HNC": 0, "FNC": 0}
        db.close()
        return redirect(url_for("sales"))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/clearcachesales")
def clearsales():
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/bookInfo/Book.db", "c")
        db.pop("bought")
        db.close()
        return redirect(url_for("sales"))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/clearcachelang")
def clearlang():
    try:
        session["employee_session"]
        db = shelve.open("database/shelve/bookInfo/Book.db", "c")
        db["data_dict_language"] = {"English": 0, "Chinese": 0, "Japanese": 0}
        db.close()
        return redirect(url_for("sales"))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


# ZHOU JIE CODE------------------------------------------------------START

@app.route("/login", methods=['GET', 'POST'])
def login():
    login_user_form = LoginForm(request.form)

    errormessage = ""

    if request.method == "POST" and login_user_form.validate():

        users_dict = {}  ## <--- for testing also

        db = shelve.open("database/shelve/userInfo/account.db", "c")

        try:
            users_dict = db["userAcc"]  # first run will have error, just run again

        except:
            print("Error in retrieving Users from storage.db.")

        db.close()

        # for uid in users_dict:
        #     print(uid,users_dict[uid].get_name(),users_dict[uid].get_password())
        # print(login_user_form.name.data)
        for uid in users_dict:
            print(uid, users_dict[uid].get_name(), users_dict[uid].get_password())
            if users_dict[uid].get_name() == login_user_form.name.data and users_dict[
                uid].get_password() == login_user_form.password.data:

                session['user_session'] = login_user_form.name.data
                session['user_uid'] = uid
                print(session["user_session"])
                return redirect(url_for('home'))
                break
            else:
                errormessage = "Username or Password is Incorrect"

    return render_template("login.html", form=login_user_form,
                           err=errormessage)  # save the input if something went wrong


@app.route('/login_employee', methods=["POST", "GET"])  # 1 admin1 admin1@gmail.com pass
def login_employee():
    login_user_form = LoginForm(request.form)
    errormessage = ""

    if request.method == "POST" and login_user_form.validate():

        users_dict = {}  ## <--- for testing also

        db = shelve.open("database/shelve/employeeInfo/account.db", "c")
        errormess = ""
        try:
            users_dict = db["employeeAcc"]  # first run will have error, just run again

        except:
            print("Error in retrieving Users from storage.db.")

        db.close()

        # for uid in users_dict:
        #     print(uid,users_dict[uid].get_name(),users_dict[uid].get_password())
        # print(login_user_form.name.data)
        for uid in users_dict:
            print(uid, users_dict[uid].get_name(), users_dict[uid].get_password())
            if users_dict[uid].get_name() == login_user_form.name.data and users_dict[
                uid].get_password() == login_user_form.password.data:
                session['employee_session'] = login_user_form.name.data
                return redirect(url_for("staffhome"))
            else:
                errormessage = "Username or Password is Incorrect"

    return render_template("login_employee.html", form=login_user_form,
                           err=errormessage)  # save the input if something went wrong


@app.route("/logout")
def logout():
    try:
        for key in session.keys():
            session.pop(key)
    except:
        pass

    return redirect(url_for("home"))


@app.route("/register", methods=['GET', 'POST'])
def register():
    create_user_form = CreateUserForm(request.form)

    if request.method == "POST" and create_user_form.validate() and val_name(create_user_form.name.data) == True:

        users_dict = {}  ## <--- for testing also

        db = shelve.open("database/shelve/userInfo/account.db", "c")

        try:
            users_dict = db["userAcc"]  # first run will have error, just run again

        except:
            print("Error in retrieving Users from storage.db.")

        count = 1
        for uid in users_dict:
            if count <= users_dict[uid].get_uid():
                count = users_dict[uid].get_uid() + 1

        user = CustomerAccount(count, create_user_form.name.data, create_user_form.password.data,
                               create_user_form.email.data, "https://freesvg.org/img/abstract-user-flat-4.png", "", "",
                               "", "", "")
        users_dict[count] = user
        db["userAcc"] = users_dict
        users_dict = db["userAcc"]
        db.close()
        # for x in users_dict:
        # print(users_dict[x].get_uid(),users_dict[x].get_name(),users_dict[x].get_email(),users_dict[x].get_password())

        return redirect(url_for('create_Success'))
    else:
        return render_template("register.html", form=create_user_form)  # save the input if something went wrong


@app.route("/createSuccess")
def create_Success():
    return render_template("createSuccess.html")


def val_name(name):
    if os.path.isfile('database/shelve/userInfo/account.db.bak'):
        users_dict = {}
        db = shelve.open('database/shelve/userInfo/account.db', 'c')
        try:
            users_dict = db['userAcc']
        except:
            users_dict = {}
        db.close()

        for x in users_dict:
            if users_dict[x].get_name() == name:
                pymsgbox.alert('NAME exists', 'ERROR')
                return False

        return True


    else:
        return True


def val_name_staff(name):
    if os.path.isfile('database/shelve/employeeInfo/account.db.bak'):
        users_dict = {}
        db = shelve.open('database/shelve/employeeInfo/account.db', 'c')
        users_dict = db['employeeAcc']
        db.close()

        for x in users_dict:
            if users_dict[x].get_name() == name:
                pymsgbox.alert('NAME exists', 'ERROR')
                return False

        return True


    else:
        return True


# def val_name_book(isbn13):
#     if os.path.isfile('database/shelve/bookInfo/Book.db.bak'):
#         users_dict = {}
#         db = shelve.open('database/shelve/bookInfo/Book.db', 'c')
#         users_dict = db['BookInfo']
#         db.close()
#
#
#         for x in users_dict:
#             if users_dict[x].get_isbn13()==isbn13:
#
#                 pymsgbox.alert('ISBN exists', 'ERROR')
#                 return False
#
#         return True
#
#
#     else:
#         return True
#
#


@app.route("/createBook",
           methods=['GET', 'POST'])  # post cause want sending data ,post will link with createUser.html POST
def create_user():  # handerling data so post
    try:
        session["employee_session"]
        create_user_form = CreateBook(request.form)  # receives the form posted by the createUser.html template.
        # post submit button press, request.method look from .route for the page
        if request.method == "POST" and create_user_form.validate():  # and val_name_book(create_user_form.isbn13.data) == True

            # # database part---------------------------------

            users_dict = {}  ## <--- for testing also

            db = shelve.open('database/shelve/bookInfo/Book.db', 'c')

            try:
                users_dict = db["BookInfo"]  # first run will have error, just run again

            except:
                print("Error in retrieving Users from storage.")

            count = 1
            for id in users_dict:
                if count <= users_dict[id].get_bookID():
                    count = users_dict[id].get_bookID() + 1
            # test insert
            category = []
            if create_user_form.category1.data == "Cartoon":
                category.append(create_user_form.category1.data)
            if create_user_form.category2.data == "Horror":
                category.append(create_user_form.category2.data)
            if create_user_form.category3.data == "Fiction":
                category.append(create_user_form.category3.data)
            price1 = str(create_user_form.price.data)
            price = price1.split(".")
            if len(price[1]) >= 2:
                price2 = round(int(price[1]), 2)
            else:
                price2 = price[1] + "0"
            price = price[0] + "." + price2
            user = Book.Book(count, create_user_form.title.data, create_user_form.image.data,
                             create_user_form.description.data, create_user_form.language.data,
                             create_user_form.status.data, create_user_form.isbn13.data, price,
                             category)
            users_dict[user.get_bookID()] = user  ##put in dic
            db["BookInfo"] = users_dict  # insert into database

            #  ## test retrieve
            #
            #
            # users_dict = db['Users']  #get all data from db["Users"] into a users_dict directory
            # user = users_dict[user.get_user_id()]
            # #print(user.get_first_name(), user.get_last_name(), "was stored in storage successfully with user_id ==", user.get_user_id())

            # ##or
            users_dict = db['BookInfo']  # get all data from db["Users"] into a users_dict directory
            for x in users_dict:
                print(users_dict[x].get_bookID(), users_dict[x].get_bookTitle(), users_dict[x].get_bookIMG(),
                      users_dict[x].get_bookDescription(), users_dict[x].get_bookLanguage(),
                      users_dict[x].get_bookStatus(),
                      users_dict[x].get_isbn13())

            db.close()
            if create_user_form.language.data.upper() == "ENGLISH":
                engdb = shelve.open("database/shelve/bookInfo/Book.db", "c")
                eng_users_dict = {}
                try:
                    eng_users_dict = engdb["EngInfo"]
                except:
                    print("Error in retrieving Books from Book.db")
                eng_users_dict[user.get_bookID()] = user
                engdb["EngInfo"] = eng_users_dict
                eng_users_dict = engdb["EngInfo"]
                db.close()
            elif create_user_form.language.data.upper() == "CHINESE":
                chdb = shelve.open("database/shelve/bookInfo/Book.db", "c")
                ch_users_dict = {}
                try:
                    ch_users_dict = chdb["ChInfo"]
                except:
                    print("Error in retrieving Books from Book.db")
                ch_users_dict[user.get_bookID()] = user
                chdb["ChInfo"] = ch_users_dict
                ch_users_dict = chdb["ChInfo"]
                db.close()
            elif create_user_form.language.data.upper() == "JAPANESE":
                jpdb = shelve.open("database/shelve/bookInfo/Book.db", "c")
                jp_users_dict = {}
                try:
                    jp_users_dict = jpdb["JpInfo"]
                except:
                    print("Error in retrieving Books from Book.db")
                jp_users_dict[user.get_bookID()] = user
                jpdb["JpInfo"] = jp_users_dict
                jp_users_dict = jpdb["JpInfo"]
                db.close()
            return redirect(url_for("editBook_employee"))

        return render_template("createBook.html", form=create_user_form)  # save the input if something went wrong
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/editBook_employee")
def editBook_employee():
    try:
        session['employee_session']
    except:
        return redirect((url_for("login_employee")))
    else:

        if os.path.isfile('database/shelve/bookInfo/Book.db.bak'):

            books_dict = {}
            db = shelve.open('database/shelve/bookInfo/Book.db', 'r')
            books_dict = db['BookInfo']
            db.close()

            book_list = []
            for key in books_dict:
                book = books_dict.get(key)
                book_list.append(book)
                # print(book)

            ##same as
            # for x in users_dict:
            #     users_list.append(users_dict[x])

            arrival_Books_dict = {}
            db = shelve.open('database/shelve/sell/sell.db', 'c') #for new arrival books
            try:
                arrival_Books_dict = db['Sell']
            except:
                print("Error in in retrieving Books from sell.db.")
            db.close()

            arrival_Book_list = []
            for key in arrival_Books_dict:
                arrival_book = arrival_Books_dict.get(key)
                arrival_book.set_bookStatus("Available")
                arrival_Book_list.append(arrival_book)
                # print(book)

            return render_template('editBook_employee.html', arrival_Book_list=arrival_Book_list, book_list=book_list,
                                   Book=True, count=len(book_list))

        return render_template('editBook_employee.html', Book=False)


@app.route("/updateBook_employee/<int:id>", methods=["GET", "POST"])
def updateBook_employee(id):  # id  var get from ^

    try:
        session['employee_session']
    except:
        return redirect((url_for("login_employee")))
    else:

        update_book_form = CreateBook(request.form)

        if request.method == "POST" and update_book_form.validate():

            books_dict = {}
            db = shelve.open('database/shelve/bookInfo/Book.db', 'c')
            books_dict = db['BookInfo']
            eng_dict = db["EngInfo"]
            ch_dict = db["ChInfo"]
            jp_dict = db["JpInfo"]
            category = []
            if update_book_form.category1.data == "Cartoon":
                category.append(update_book_form.category1.data)
            if update_book_form.category2.data == "Horror":
                category.append(update_book_form.category2.data)
            if update_book_form.category3.data == "Fiction":
                category.append(update_book_form.category3.data)
            price1 = str(update_book_form.price.data)
            price = price1.split(".")
            if len(price[1]) >= 2:
                price2 = price[1][0:2]
            else:
                price2 = price[1] + "0"
            price = str(price[0]) + "." + str(price2)
            book = books_dict.get(id)
            prev_lang = book.get_bookLanguage()
            print(prev_lang)
            book.set_bookTitle(update_book_form.title.data)
            book.set_bookIMG(update_book_form.image.data)
            book.set_bookDescription(update_book_form.description.data)
            book.set_isbn13(update_book_form.isbn13.data)
            book.set_bookStatus(update_book_form.status.data)
            book.set_bookLanguage(update_book_form.language.data)
            book.set_price(price)
            book.set_category(category)
            books_dict[id] = book
            db['BookInfo'] = books_dict
            if prev_lang != update_book_form.language.data:
                if update_book_form.language.data == "English":
                    eng_dict[id] = Book.Book(id, update_book_form.title.data, update_book_form.image.data,
                                             update_book_form.description.data, update_book_form.language.data,
                                             update_book_form.status.data, update_book_form.isbn13.data, price,
                                             category)
                    db['EngInfo'] = eng_dict
                elif update_book_form.language.data == "Chinese":
                    ch_dict[id] = Book.Book(id, update_book_form.title.data, update_book_form.image.data,
                                            update_book_form.description.data, update_book_form.language.data,
                                            update_book_form.status.data, update_book_form.isbn13.data, price,
                                            category)
                    db["ChInfo"] = ch_dict
                elif update_book_form.language.data == "Japanese":
                    jp_dict[id] = Book.Book(id, update_book_form.title.data, update_book_form.image.data,
                                            update_book_form.description.data, update_book_form.language.data,
                                            update_book_form.status.data, update_book_form.isbn13.data, price,
                                            category)
                    db["JpInfo"] = jp_dict
            else:
                book2 = eng_dict.get(id)
                book3 = ch_dict.get(id)
                book4 = jp_dict.get(id)
                if update_book_form.language.data == "English":
                    book2.set_bookTitle(update_book_form.title.data)
                    book2.set_bookIMG(update_book_form.image.data)
                    book2.set_bookDescription(update_book_form.description.data)
                    book2.set_isbn13(update_book_form.isbn13.data)
                    book2.set_bookStatus(update_book_form.status.data)
                    book2.set_bookLanguage(update_book_form.language.data)
                    book2.set_price(price)
                    book2.set_category(category)
                    eng_dict[id] = book2
                    db['EngInfo'] = eng_dict
                elif update_book_form.language.data == "Chinese":
                    book3.set_bookTitle(update_book_form.title.data)
                    book3.set_bookIMG(update_book_form.image.data)
                    book3.set_bookDescription(update_book_form.description.data)
                    book3.set_isbn13(update_book_form.isbn13.data)
                    book3.set_bookStatus(update_book_form.status.data)
                    book3.set_bookLanguage(update_book_form.language.data)
                    book3.set_price(price)
                    book3.set_category(category)
                    ch_dict[id] = book3
                    db['ChInfo'] = ch_dict
                elif update_book_form.language.data == "Japanese":
                    book4.set_bookTitle(update_book_form.title.data)
                    book4.set_bookIMG(update_book_form.image.data)
                    book4.set_bookDescription(update_book_form.description.data)
                    book4.set_isbn13(update_book_form.isbn13.data)
                    book4.set_bookStatus(update_book_form.status.data)
                    book4.set_bookLanguage(update_book_form.language.data)
                    book4.set_price(price)
                    book4.set_category(category)
                    jp_dict[id] = book4
                    db['JpInfo'] = jp_dict
            if prev_lang != update_book_form.language.data:
                if prev_lang == "English":
                    eng_dict.pop(id)
                    db["EngInfo"] = eng_dict
                elif prev_lang == "Chinese":
                    ch_dict.pop(id)
                    db["ChInfo"] = ch_dict
                elif prev_lang == "Japanese":
                    jp_dict.pop(id)
                    db["JpInfo"] = jp_dict
            db.close()
            #     for i in range(len(books_list)):
            # try:
            #     books_list[i].set_bookTitle(update_book_form.title.data)
            #     books_list[i].set_bookIMG(update_book_form.image.data)
            #     books_list[i].set_bookDescription(update_book_form.description.data)
            #     books_list[i].set_isbn13(update_book_form.isbn13.data)
            #     books_list[i].set_bookStatus(update_book_form.status.data)
            #     books_list[i].set_bookLanguage(update_book_form.language.data)
            #     books_list[i].set_price(price)
            #     books_list[i].set_category(category)
            #     db[info] = dict
            # except:
            #     pass
            return redirect(url_for("editBook_employee"))

        else:

            db = shelve.open('database/shelve/bookInfo/Book.db', 'c')
            books_dict = db['BookInfo']
            db.close()

            user = books_dict.get(id)
            update_book_form.title.data = user.get_bookTitle()
            update_book_form.image.data = user.get_bookIMG()
            update_book_form.description.data = user.get_bookDescription()
            update_book_form.status.data = user.get_bookStatus()
            update_book_form.isbn13.data = user.get_isbn13()
            update_book_form.price.data = user.get_price()
            update_book_form.language.data = user.get_bookLanguage()
            prev_lang = user.get_bookLanguage()
            if "Horror" in user.get_category():
                update_book_form.category2.data = "Horror"
            else:
                update_book_form.category2.data = "Not Horror"
            if "Cartoon" in user.get_category():
                update_book_form.category1.data = "Cartoon"
            else:
                update_book_form.category1.data = "Not Cartoon"
            if "Fiction" in user.get_category():
                update_book_form.category3.data = "Fiction"
            else:
                update_book_form.category3.data = "Not Fiction"

            return render_template('updateBook_employee.html', form=update_book_form)


@app.route('/deleteBook_employee/<int:id>', methods=['POST'])
def deleteBook_employee(id):
    try:
        session["employee_session"]
        books_dict = {}
        db = shelve.open('database/shelve/bookInfo/Book.db', 'c')
        key = ["BookInfo", "EngInfo", "ChInfo", "JpInfo"]
        for i in range(len(key)):
            try:
                books_dict = db[key[i]]
            except:
                books_dict = {}
            try:
                books_dict.pop(id)
                db[key[i]] = books_dict
            except:
                print("Book not found in Book[" + key[i] + "] database.")
        db.close()
        db2 = shelve.open("database/shelve/userInfo/account.db", "c")
        user_dict = db2["userAcc"]
        user_list = []
        for user in user_dict:
            item = user_dict.get(user)
            user_list.append(item)
        for i in user_list:
            for x in i.get_borrowCart():
                if str(x.get_bookID()) == str(id):
                    index = user_dict[i.get_uid()].get_borrowCart().index(x)
                    user_dict[i.get_uid()].get_borrowCart().pop(index)
        for i in user_list:
            for x in i.get_buyCart():
                if str(x.get_bookID()) == str(id):
                    index = user_dict[i.get_uid()].get_buyCart().index(x)
                    user_dict[i.get_uid()].get_buyCart().pop(index)
        db2["userAcc"] = user_dict
        db2.close()

        return redirect(url_for('editBook_employee'))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


# @app.route('/hello/<int:id>', methods=['POST'])
# def hello(id):
#     print(id,"Hello")
#     return redirect(url_for('home'))

@app.route("/acceptArrival_employee/<int:id>", methods=['POST', 'GET'])
def acceptArrival_employee(id):  # id  var get from ^

    try:
        session["employee_session"]
        form = CreateBook(request.form)
        if request.method == "POST" and form.validate():
            new_arrival_dict = {}  ## <--- for testing also

            db = shelve.open('database/shelve/sell/sell.db', 'c')

            try:
                new_arrival_dict = db['Sell']  # first run will have error, just run again
                # new_arrival_dict.pop(id)
                # db['Sell']=new_arrival_dict


            except:
                print("Error in retrieving data from sell.db")

            db.close()

            book_dict = {}  ## <--- for testing also

            db = shelve.open('database/shelve/bookInfo/Book.db', 'c')

            try:
                book_dict = db['BookInfo']  # first run will have error, just run again

            except:
                print("Error in retrieving data from book.db")

            count = 1
            for x in book_dict:
                if count <= book_dict[x].get_bookID():
                    count = book_dict[x].get_bookID() + 1
            # ##test insert
            addBook = new_arrival_dict[id]
            print(addBook.get_bookTitle())
            addBook.set_price(form.price.data)
            category = []
            if form.category1.data == "Cartoon":
                category.append(form.category1.data)
            if form.category2.data == "Horror":
                category.append(form.category2.data)
            if form.category3.data == "Fiction":
                category.append(form.category3.data)
            book = Book.Book(count, addBook.get_bookTitle(), addBook.get_bookIMG(),
                             addBook.get_bookDescription(), addBook.get_bookLanguage(), addBook.get_bookStatus(),
                             addBook.get_isbn13(), addBook.get_price(), category)

            book_dict[count] = book  ##put in dic
            db["BookInfo"] = book_dict  # insert into database
            if addBook.get_bookLanguage().upper() == "ENGLISH":
                try:
                    book_dict = db["EngInfo"]
                except:
                    book_dict = {}
                    print('Error from retrieving EngInfo from Book["EngInfo"]')
                book_dict[count] = book
                db["EngInfo"] = book_dict
            elif addBook.get_bookLanguage().upper() == "CHINESE":
                try:
                    book_dict = db["ChInfo"]
                except:
                    book_dict = {}
                    print('Error from retrieving EngInfo from Book["ChInfo"]')
                book_dict[count] = book
                db["ChInfo"] = book_dict
            elif addBook.get_bookLanguage().upper() == "JAPANESE":
                try:
                    book_dict = db["JpInfo"]
                except:
                    book_dict = {}
                    print('Error from retrieving EngInfo from Book["JpInfo"]')
                book_dict[count] = book
                db["JpInfo"] = book_dict
            db.close()

            new_arrival_dict = {}

            db = shelve.open('database/shelve/sell/sell.db', 'c')

            try:
                new_arrival_dict = db['Sell']  # first run will have error, just run again
                # new_arrival_dict.pop(id)
                # db['Sell']=new_arrival_dict


            except:
                print("Error in retrieving data from sell.db")

            db.close()

            new_arrival_dict = {}

            db = shelve.open('database/shelve/sell/sell.db', 'c')

            try:
                new_arrival_dict = db['Sell']  # first run will have error, just run again
                new_arrival_dict.pop(id)
                db['Sell'] = new_arrival_dict


            except:
                print("Error in retrieving data from sell.db")

            db.close()

            return redirect(url_for('editBook_employee'))
        else:
            book_dict = {}
            db = shelve.open('database/shelve/sell/sell.db', 'c')
            try:
                book_dict = db['Sell']
            except:
                print("Error in retrieving data from sell.db")
            db.close()
            book = book_dict.get(id)
            form.title.data = book.get_bookTitle()
            form.image.data = book.get_bookIMG()
            form.description.data = book.get_bookDescription()
            form.language.data = book.get_bookLanguage()
            form.status.data = book.get_bookStatus()
            form.isbn13.data = book.get_isbn13()
            return render_template('updateBook.html', form=form)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route('/deleteArrival_employee/<int:id>', methods=['POST'])
def deleteArrival_employee(id):
    try:
        session["employee_session"]
        sell_dict = {}
        db = shelve.open('database/shelve/sell/sell.db', 'c')
        db2 = shelve.open("database/shelve/userInfo/account.db", "c")
        user_dict = db2["userAcc"]
        sell_dict = db['Sell']
        user_list = []
        book = sell_dict[id]
        sell_dict.pop(id)
        for user in user_dict:
            item = user_dict.get(user)
            user_list.append(item)
        for i in user_list:
            for x in i.get_sell():
                if str(x.get_bookID()) == str(id):
                    index = user_dict[i.get_uid()].get_sell().index(x)
                    user_dict[i.get_uid()].get_sell().pop(index)
        db2["userAcc"] = user_dict
        db['Sell'] = sell_dict
        db.close()
        db2.close()
        return redirect(url_for('editBook_employee'))
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/updateProfile/<int:id>", methods=["GET", "POST"])
def updateProfile(id):
    try:
        session['user_session'] = session['user_session']
    except:
        return redirect((url_for("login")))
    else:

        update_profile_form = UpdateProfileForm(request.form)
        if request.method == "POST" and update_profile_form.validate() and (
                session["user_session"] == update_profile_form.name.data or val_name(
                update_profile_form.name.data) == True):
            user_dict = {}
            db = shelve.open("database/shelve/userInfo/account.db", "c")
            user_dict = db['userAcc']

            user = user_dict.get(id)
            user.set_name(update_profile_form.name.data)
            user.set_email(update_profile_form.email.data)
            user.set_image(update_profile_form.image.data)
            user.set_blog(update_profile_form.blog.data)

            db['userAcc'] = user_dict
            db.close()

            session["user_session"] = update_profile_form.name.data

            return redirect(url_for("profile"))
        else:

            db = shelve.open("database/shelve/userInfo/account.db", "c")
            user_dict = db['userAcc']
            db.close()

            user = user_dict.get(id)
            update_profile_form.name.data = user.get_name()
            update_profile_form.email.data = user.get_email()
            update_profile_form.image.data = user.get_image()
            update_profile_form.blog.data = user.get_blog()
            return render_template('updateProfile.html', form=update_profile_form)


@app.route("/changePassword/<int:id>", methods=["GET", "POST"])
def changePassword(id):
    change_password_form = ChangePasswordForm(request.form)
    if request.method == "POST" and change_password_form.validate():
        user_dict = {}
        db = shelve.open("database/shelve/userInfo/account.db", "c")
        user_dict = db['userAcc']

        user = user_dict.get(id)

        user.set_password(change_password_form.password.data)

        db['userAcc'] = user_dict
        db.close()

        return redirect(url_for("profile"))
    else:

        db = shelve.open("database/shelve/userInfo/account.db", "c")
        user_dict = db['userAcc']
        db.close()

        # update_profile_form.password.data = employee.get_password()
        # update_profile_form.confirm.data = employee.get_password()
        return render_template('changePassword.html', form=change_password_form)


@app.route("/profile_employee")
def profile_employee():
    try:
        session['employee_session']
    except:
        return redirect((url_for("login_employee")))
    else:

        try:

            db = shelve.open("database/shelve/employeeInfo/account.db", "c")

            employee_dict = db['employeeAcc']

            db.close()
            users_dict = {}  ## <--- for testing also




        except:

            return redirect(url_for('login_employee'))

        else:

            for uid in employee_dict:
                if employee_dict[uid].get_name() == session["employee_session"]:
                    admin = employee_dict[uid]
                    # admin=session["employee_session"]

                    return render_template("profile_employee.html", admin=admin)  # ,sess=session["employee_session"]


@app.route("/profile")
def profile():
    try:
        session['user_session']
    except:
        return redirect((url_for("login")))
    else:

        try:
            db = shelve.open("database/shelve/userInfo/account.db", "c")

            employee_dict = db['userAcc']

            db.close()
            users_dict = {}  ## <--- for testing also
        except:

            return redirect(url_for('login'))

        else:

            for uid in employee_dict:
                if employee_dict[uid].get_name() == session["user_session"]:
                    user = employee_dict[uid]

                    return render_template("profile.html", user=user)


@app.route("/updateProfile_employee/<int:id>", methods=["GET", "POST"])
def updateProfile_employee(id):
    try:
        session["employee_session"]
        update_profile_form = UpdateProfileEmployeeForm(request.form)
        if request.method == "POST" and update_profile_form.validate() and (
                session["employee_session"] == update_profile_form.name.data or val_name_staff(
                update_profile_form.name.data) == True):
            user_dict = {}

            db = shelve.open('database/shelve/employeeInfo/account.db', 'c')
            employee_dict = db['employeeAcc']

            employee = employee_dict.get(id)
            employee.set_name(update_profile_form.name.data)
            employee.set_email(update_profile_form.email.data)
            employee.set_image(update_profile_form.image.data)

            db['employeeAcc'] = employee_dict
            db.close()

            session["employee_session"] = update_profile_form.name.data
            return redirect(url_for("profile_employee"))
        else:

            db = shelve.open('database/shelve/employeeInfo/account.db', 'c')
            employee_dict = db['employeeAcc']
            db.close()

            employee = employee_dict.get(id)
            update_profile_form.name.data = employee.get_name()
            update_profile_form.email.data = employee.get_email()
            update_profile_form.image.data = employee.get_image()

            return render_template('updateProfile_employee.html', form=update_profile_form)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/changePassword_employee/<int:id>", methods=["GET", "POST"])
def changePassword_employee(id):
    try:
        session["employee_session"]
        change_password_form = ChangePasswordForm(request.form)
        if request.method == "POST" and change_password_form.validate():
            employee_dict = {}
            db = shelve.open('database/shelve/employeeInfo/account.db', 'c')
            employee_dict = db['employeeAcc']

            employee = employee_dict.get(id)

            employee.set_password(change_password_form.password.data)

            db['employeeAcc'] = employee_dict
            db.close()

            return redirect(url_for("profile_employee"))
        else:

            db = shelve.open("database/shelve/userInfo/account.db", "c")
            user_dict = db['employeeAcc']
            db.close()

            # update_profile_form.password.data = employee.get_password()
            # update_profile_form.confirm.data = employee.get_password()
            return render_template('changePassword_employee.html', form=change_password_form)
    except:
        try:
            session["user_session"]
        except:
            return redirect(url_for("login"))
        else:
            return redirect(url_for("home"))


@app.route("/returnBook/<int:id>", methods=["GET", "POST"])
def returnBook(id):
    db = shelve.open("database/shelve/userInfo/account.db", "r")
    users_dict = db["userAcc"]
    db.close()
    books = users_dict[id].get_borrowed()
    borrow_list = []
    for borrow in books:
        borrow_list.append(borrow)
    return render_template("returnBook.html", borrow_list=borrow_list)


@app.route("/browse")
def browse():
    return render_template("browse.html")


@app.route("/englishSearch")
def englishSearch():
    return render_template("englishSearch.html")


@app.route("/chineseSearch")
def chineseSearch():
    return render_template("chineseSearch.html")


@app.route("/japaneseSearch")
def japaneseSearch():
    return render_template("japaneseSearch.html")


@app.route("/allSearch")
def allSearch():
    return render_template("allSearch.html")


@app.route("/categorySearch/<Language>/<Category>")
def categorySearch(Language, Category):
    # language 1,2,3 (ENGLISH,CHINESE,Japanese)
    # Category 1,2,3 (CARTOON, HORROR, FICTION)
    # datasource=""

    if os.path.isfile('database/shelve/bookInfo/Book.db.bak'):

        books_dict = {}
        db = shelve.open('database/shelve/bookInfo/Book.db', 'r')
        books_dict = db['BookInfo']
        db.close()

        book_list = []


        # English>Category
        new_book_list = []
        if Language == "1":
            for key in books_dict:
                book = books_dict.get(key)

                if book.get_bookLanguage() == "English":
                    new_book_list.append(book)
            if Category == "1":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Cartoon":
                            book_list.append(book)

            elif Category == "2":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Horror":
                            book_list.append(book)


            elif Category == "3":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Fiction":
                            book_list.append(book)
            else:
                book_list = new_book_list

        # Chinese>Category
        elif Language == "2":
            for key in books_dict:
                book = books_dict.get(key)

                if book.get_bookLanguage() == "Chinese":
                    new_book_list.append(book)
            if Category == "1":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Cartoon":
                            book_list.append(book)

            elif Category == "2":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Horror":
                            book_list.append(book)


            elif Category == "3":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Fiction":
                            book_list.append(book)
            else:
                book_list = new_book_list

        # Japanese>Category
        elif Language == "3":
            for key in books_dict:
                book = books_dict.get(key)

                if book.get_bookLanguage() == "Japanese":
                    new_book_list.append(book)
            if Category == "1":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Cartoon":
                            book_list.append(book)

            elif Category == "2":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Horror":
                            book_list.append(book)


            elif Category == "3":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Fiction":
                            book_list.append(book)
            else:
                book_list = new_book_list
        else:
            for key in books_dict:
                book = books_dict.get(key)
                new_book_list.append(book)
            if Category == "1":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Cartoon":
                            book_list.append(book)

            elif Category == "2":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Horror":
                            book_list.append(book)


            elif Category == "3":
                for key in new_book_list:
                    book = key
                    for cha in book.get_category():
                        if cha == "Fiction":
                            book_list.append(book)
            else:
                book_list = new_book_list
        return render_template('categorySearch.html', book_list=book_list,
                               Book=True, count=len(book_list))

    return render_template('editBook_employee.html', Book=False)


@app.route("/forgetPassword", methods=['GET', 'POST'])
def forgetPassword():
    errormessage = ""
    forget_password_form = ForgetPasswordForm(request.form)
    if request.method == "POST" and forget_password_form.validate():

        users_dict = {}  ## <--- for testing also

        db = shelve.open("database/shelve/userInfo/account.db", "c")

        try:
            users_dict = db["userAcc"]  # first run will have error, just run again

        except:
            print("Error in retrieving Users from storage.db.")

        db.close()
        errormessage = ""
        for uid in users_dict:
            if users_dict[uid].get_email() == forget_password_form.email.data:
                print(forget_password_form.email.data)
                errormessage = "The Password Have Been Send To Your Email"

                email = 'test123123ASIA@gmail.com'  # company email
                password = 'efrfwesqa23@'  # company email account password
                send_to_email = users_dict[uid].get_email()
                title = "SingBook Password Recovery"
                content = "Your Username: " + users_dict[uid].get_name() + "\nYour Password: " + users_dict[
                    uid].get_password()
                message = 'Subject: {}\n\n{}'.format(title, content)
                subj = "SUBJECT"
                server = smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login(email, password)
                server.sendmail(email, send_to_email, message)
                server.quit()
                break
            else:
                errormessage = "Email Do Not Exist In The Database"

    return render_template("forgetPassword.html", form=forget_password_form,
                           err=errormessage)  # save the input if something went wrong


@app.route("/forgetPassword_employee", methods=['GET', 'POST'])
def forgetPassword_employee():
    errormessage = ""
    forget_password_form = ForgetPasswordForm(request.form)
    if request.method == "POST" and forget_password_form.validate():

        users_dict = {}  ## <--- for testing also

        db = shelve.open("database/shelve/employeeInfo/account.db", "c")

        try:
            users_dict = db["employeeAcc"]  # first run will have error, just run again

        except:
            print("Error in retrieving Users from storage.db.")

        db.close()
        errormessage = ""
        for uid in users_dict:
            if users_dict[uid].get_email() == forget_password_form.email.data:
                print(forget_password_form.email.data)
                errormessage = "The Password Have Been Send To Your Email"

                email = 'test123123ASIA@gmail.com'  # Your email
                password = 'efrfwesqa23@'  # Your email account password
                send_to_email = users_dict[uid].get_email()
                title = "SingBook Password Recovery"
                content = "Your Username: " + users_dict[uid].get_name() + "\nYour Password: " + users_dict[
                    uid].get_password()
                message = 'Subject: {}\n\n{}'.format(title, content)
                subj = "SUBJECT"
                server = smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login(email, password)
                server.sendmail(email, send_to_email, message)
                server.quit()
                break
            else:
                errormessage = "Email Do Not Exist In The Database"

    return render_template("forgetPassword.html", form=forget_password_form,
                           err=errormessage)  # save the input if something went wrong

@app.route("/contact")
def contect():

    return render_template("contact.html")
# ZHOU JIE CODE------------------------------------------------------END
@app.route('/payment', methods=['GET','POST'])
def payment():
    payment_form=Payment(request.form)
    if request.method == 'POST' and payment_form.validate():



        return redirect(url_for('home'))
    return render_template('payment.html', form=payment_form)

@app.route('/shipping',methods=['GET','POST'])
def shipping():
    shipping_form= Payment(request.form)
    if request.method == 'POST' and shipping_form.validate():


        return redirect(url_for('payment'))
    return render_template('payment.html', form=shipping_form)
if __name__ == "__main__":
    app.run(port=2000)
