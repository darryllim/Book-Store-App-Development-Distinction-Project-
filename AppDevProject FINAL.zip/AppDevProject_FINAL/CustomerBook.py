import Book as B
class CustomerBook(B):
    def __init__(self):
        pass
    # def set_bookInfo(self,name):
