from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators

class CreateSellForm(Form):
    title=StringField("TITLE:",[validators.Length(min=1,max=100),validators.DataRequired()])
    image=StringField("IMAGE:",[validators.Length(min=1,max=500),validators.DataRequired()])
    description=StringField("DESCRIPTION:",[validators.Length(min=1,max=500),validators.DataRequired()])
    isbn13=StringField("ISBN13:",[validators.Length(min=13,max=13),validators.DataRequired()])
