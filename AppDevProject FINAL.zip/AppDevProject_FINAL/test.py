# # # import shelve
from flask import session
# # # import announcements
# # # c = shelve.open("database/shelve/announcement/announcement.db", "c")
# # # announcement_dict = c["announcements"]
# # # # ann_list = []
# # # # for key in announcement_dict:
# # # #     ann_list.append(key)
# # # # print(ann_list)
# # # # print(ann_dict[0].get_announcement_id().get_announcement_id())
# # # c.close()
# # # # dict = {}
# # # # dict["cunt"] = "dick"
# # # # print(dict)
# # list = [1,2,3,4,5,6]
# # list.pop()
# # print(list)
# for z in range(2):
#     print("hi")
# print(z)
import shelve
# import Book
from faq import Questions
# db = shelve.open("database/shelve/faq/faq.db","r")
# print(db["Question"][0].get_question_id())
# from Account import EmployeeAccount
# db = shelve.open("database/shelve/bookInfo/Book.db","c")
# db2 = shelve.open("database/shelve/bookInfo/english/Book.db","r")
# db3 = shelve.open("database/shelve/bookInfo/chinese/Book.db","r")
# db4 = shelve.open("database/shelve/bookInfo/japanese/Book.db","r")
# db["EngInfo"] = db2["BookInfo"]
# db["ChInfo"] = db3["BookInfo"]
# db["JpInfo"] = db4["BookInfo"]
# db = shelve.open("database/shelve/faq/faq.db", "c")
# print(db["QNA"][0].get_question())
# user = EmployeeAccount(1, "admin1", "pass",
#                         "admin1@gmail.com")
# staff_dict = {}
# staff_dict[1] = user
# db["employeeAcc"] = staff_dict
# users_dict = db["employeeAcc"]
# B = db["bookInfo"][1]
# print(B.get_bookID(),B.get_bookDescription(),B.get_bookIMG(),B.get_bookStatus(),B.get_bookTitle(),B.get_isbn13())
# print(session.get("user_session"))
# x = 1
# b = 2
# while x == 2 and b ==2:
#     print("Ture")
#     break
# import random
# b_list = ["1","2"]
# done = []
# n_list = []
# id = 2
# print(len(b_list))
# for i in range(6):
#     count = random.randint(0,len(b_list)-1)
#     while count == id or count in done:
#         count = random.randint(0,len(b_list)-1)
#         print(count)
#     done.append(count)
#     n_list.append(b_list[count])
# price1 = "21.0"
# price = price1.split(".")
# if len(price[1]) >= 2:
#     price2 = round(int(price[1]),2)
# else:
#     price2 = price[1]+"0"
# price = price[0]+"."+price2
# print(price)
# from Account import CustomerAccount
# x = CustomerAccount("123","Ben","Pass","eads@s.com","borrow","buy")
# x.get_borrowCart()
# dict = {1:2,4:5,6:7}
# print(dict.get(1))
# db = shelve.open('database/shelve/sell/sell.db', 'c')
# db.pop("")
# db = shelve.open("database/shelve/bookInfo/Book2.db","c")
# db2 = shelve.open("database/shelve/bookInfo/Book.db","c")
# EngInfo = db2["EngInfo"]
# ChInfo = db2["ChInfo"]
# JpInfo = db2["JpInfo"]
# Book = db2["BookInfo"]
# BookInfo = {}
# db2["BookInfo"] = db2["BookInfo"].update(db2["JpInfo"])
# for key in EngInfo:
#     books = EngInfo.get(key)
#     BookInfo[key] = books
# for key in ChInfo:
#     books = ChInfo.get(key)
#     BookInfo[(key)] = books
# for key in JpInfo:
#     books = JpInfo.get(key)
#     BookInfo[(key)] = books
# db2["BookInfo"] = BookInfo
# JpInfo[28] = Book[28]
# db2["BookInfo"] = Book
# db2["EngInfo"] = EngInfo
# db2["ChInfo"] = ChInfo
# db2["JpInfo"] = JpInfo
# db2.close()
# db.close()
# dict = {"1":"4","2":"3"}
# if "4" in dict:
#     print(True)
# list =["1","2"]
# list.pop(0)
# db = shelve.open("database/shelve/userInfo/account.db")
# db["userAcc"][1].set_sell("")
# db.close
# for i in range(3):
#     for i in range(5):
#         print(i)
#         if i ==2:
#             break
# x = ["1"]
# if "1"in x:print("ES")
# dict = {"gay":0,"chinese":0}
# if True:
#     dict["gay"] +=1
# print(dict)
# list = ["1","2"]
# if "2" and "1" in list:
#     print(True)
# list.pop("1")
# print(list)
# db = shelve.open("database/shelve/bookInfo/Book.db","c")
# db.pop("EngInfo")
# db.close()
# list = [1,2,3,4,5,6,7,8]
# print(list[0:6])
# db = shelve.open("database/shelve/userInfo/account.db","c")
# dict = db["userAcc"]
# print(db["userAcc"][1].get_name())
# db.close()
# print(dict[1].get_suggest())
# dict = {"1":1,"2":2}
# a = "1"
# print(dict[a])
import random
# random.randint(0,-1)
list = [1,2,3,4,5,6,7,8,9,0]
print(random.sample(list,2))
