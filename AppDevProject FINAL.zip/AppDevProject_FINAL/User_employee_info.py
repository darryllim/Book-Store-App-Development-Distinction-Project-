class User_employee_info:
    def __init__(self):
        pass
    #username,email,password,phoneNumber
