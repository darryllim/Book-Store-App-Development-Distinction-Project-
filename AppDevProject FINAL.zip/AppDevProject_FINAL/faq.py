import shelve
class Questions:

    def __init__(self, question):
        self.__question_id = 0
        self.__text = question

    def set_question(self, announcement):
        self.__text = announcement

    def set_question_id(self):
        db = shelve.open("database/shelve/faq/faq.db","c")
        try:
            question_dict = db["Question"]
        except:
            try:
                question_dict = db["QNA"]
            except:
                self.__question_id = 0
            else:
                if len(question_dict) == 0:
                    self.__question_id = 0
                else:
                    qn_list = []
                    for key in question_dict:
                        qn_list.append(key)
                    self.__question_id = qn_list[-1]+1
        else:
            if len(question_dict) == 0:
                try:
                    question_dict=db["QNA"]
                except:
                    self.__question_id = 0
                else:
                    if len(question_dict) == 0:
                        self.__question_id = 0
                    else:
                        qn_list = []
                        for key in question_dict:
                            qn_list.append(key)
                        self.__question_id = qn_list[-1]+1
            else:
                qn_list = []
                for key in question_dict:
                    qn_list.append(key)
                largest = qn_list[-1]+1
                try:
                    question_dict=db["QNA"]
                except:
                    self.__question_id = largest
                else:
                    if len(question_dict) == 0:
                        self.__question_id = largest
                    else:
                        for key in question_dict:
                            qn_list.append(key)
                        if qn_list[-1]+1 > largest:
                            largest = qn_list[-1]+1
                            self.__question_id = largest
                        else:
                            self.__question_id = largest
            db.close()
        return self.__question_id

    def get_question(self):
        return self.__text

    def get_question_id(self):
        return self.__question_id
