import Book as B
class EmployeeBook(B):
    def __init__(self):
        pass

