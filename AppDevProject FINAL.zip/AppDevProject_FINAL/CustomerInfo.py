import User_employee_info as Info
class CustomerInfo(Info):
    def __init__(self):
        pass
